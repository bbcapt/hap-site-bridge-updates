<?php
/**
 * AES-128-CTR compatible with CRM hap_encrypt / hap_decrypt.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Hap_Bridge_Crypto {

	/**
	 * Same defaults as CRM Hap-Manager (override via wp-config on the site).
	 *
	 * @return string
	 */
	public static function iv() {
		if ( defined( 'HAP_CRM_ENCRYPT_IV' ) && HAP_CRM_ENCRYPT_IV ) {
			return (string) HAP_CRM_ENCRYPT_IV;
		}
		return '7846290857246738';
	}

	/**
	 * @return string
	 */
	public static function key() {
		if ( defined( 'HAP_CRM_ENCRYPT_KEY' ) && HAP_CRM_ENCRYPT_KEY ) {
			return (string) HAP_CRM_ENCRYPT_KEY;
		}
		return 'jbjb/UTG7oih89ye1io,ò,pi0';
	}

	/**
	 * @param string $string Plain text.
	 * @return string
	 */
	public static function encrypt( $string ) {
		return openssl_encrypt(
			(string) $string,
			'AES-128-CTR',
			self::key(),
			0,
			self::iv()
		);
	}

	/**
	 * @param array<int,scalar> $values Plain values.
	 * @return array<int,string> Encrypted strings (list).
	 */
	public static function encrypt_list( array $values ) {
		$out = array();
		foreach ( $values as $value ) {
			$out[] = self::encrypt( (string) $value );
		}
		return $out;
	}
}
