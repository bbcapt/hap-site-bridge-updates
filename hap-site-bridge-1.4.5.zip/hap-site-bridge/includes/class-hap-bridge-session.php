<?php
/**
 * Short-lived HAP write sessions.
 *
 * @package HapSiteBridge
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Session store (transients keyed by token hash).
 */
class Hap_Bridge_Session {

	/**
	 * @param array<string,mixed> $data Session payload.
	 * @return array{session_id:string,token:string,expires_at:int}
	 */
	public static function create( array $data ) {
		$token      = bin2hex( random_bytes( 32 ) );
		$token_hash = hash( 'sha256', $token );
		$session_id = wp_generate_uuid4();
		$ttl        = isset( $data['ttl_seconds'] ) ? (int) $data['ttl_seconds'] : Hap_Bridge_Auth::SESSION_DEFAULT;
		$ttl        = max( 60, min( 900, $ttl ) );
		$expires    = time() + $ttl;

		$payload = array(
			'session_id'    => $session_id,
			'connection_id' => (string) ( $data['connection_id'] ?? '' ),
			'site_id'       => (string) ( $data['site_id'] ?? '' ),
			'deployment_id' => (string) ( $data['deployment_id'] ?? '' ),
			'scopes'        => isset( $data['scopes'] ) && is_array( $data['scopes'] ) ? $data['scopes'] : array(),
			'expires_at'    => $expires,
			'created_at'    => time(),
		);

		set_transient( 'hap_bs_' . $token_hash, $payload, $ttl );
		set_transient( 'hap_bsid_' . $session_id, $token_hash, $ttl );

		return array(
			'session_id' => $session_id,
			'token'      => $token,
			'expires_at' => $expires,
		);
	}

	/**
	 * @param string $token Session token.
	 * @param string $scope Required scope.
	 * @param WP_REST_Request|null $request Request for deployment binding.
	 * @return true|WP_Error
	 */
	public static function authorize_token( $token, $scope, $request = null ) {
		$https = Hap_Bridge_Auth::require_https();
		if ( is_wp_error( $https ) ) {
			return $https;
		}

		$token_hash = hash( 'sha256', (string) $token );
		$payload    = get_transient( 'hap_bs_' . $token_hash );
		if ( ! is_array( $payload ) ) {
			return new WP_Error( 'hap_bridge_session_invalid', 'Invalid or expired session.', array( 'status' => 401 ) );
		}
		if ( time() > (int) $payload['expires_at'] ) {
			self::destroy_by_hash( $token_hash );
			return new WP_Error( 'hap_bridge_session_expired', 'Session expired.', array( 'status' => 401 ) );
		}

		$scopes = isset( $payload['scopes'] ) ? $payload['scopes'] : array();
		if ( ! in_array( $scope, $scopes, true ) ) {
			return new WP_Error( 'hap_bridge_scope_denied', 'Scope not allowed.', array( 'status' => 403 ) );
		}

		if ( $request && '' !== (string) ( $payload['deployment_id'] ?? '' ) ) {
			$body = $request->get_json_params();
			if ( is_array( $body ) && ! empty( $body['deployment_id'] ) ) {
				if ( ! hash_equals( (string) $payload['deployment_id'], (string) $body['deployment_id'] ) ) {
					return new WP_Error( 'hap_bridge_deployment_mismatch', 'Deployment id mismatch.', array( 'status' => 403 ) );
				}
			}
		}

		return true;
	}

	/**
	 * @param string $session_id Session id.
	 * @return bool
	 */
	public static function close( $session_id ) {
		$token_hash = get_transient( 'hap_bsid_' . $session_id );
		if ( ! $token_hash ) {
			return false;
		}
		self::destroy_by_hash( (string) $token_hash );
		delete_transient( 'hap_bsid_' . $session_id );
		return true;
	}

	/**
	 * @param string $token_hash Token hash.
	 */
	private static function destroy_by_hash( $token_hash ) {
		delete_transient( 'hap_bs_' . $token_hash );
	}
}
