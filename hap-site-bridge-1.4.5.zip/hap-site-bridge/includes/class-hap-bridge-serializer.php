<?php
/**
 * Serialize WP posts to stable JSON for contract discovery / examples.
 *
 * @package HapSiteBridge
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Versioned post serializer (no AI).
 */
class Hap_Bridge_Serializer {

	public const VERSION = 1;

	/**
	 * @param int    $post_id Post ID.
	 * @param string $mode hap_studio|generic.
	 * @return array<string,mixed>|WP_Error
	 */
	public static function serialize_post( $post_id, $mode = '' ) {
		$post = get_post( (int) $post_id );
		if ( ! $post ) {
			return new WP_Error( 'hap_bridge_not_found', 'Post not found.', array( 'status' => 404 ) );
		}

		if ( '' === $mode ) {
			$mode = function_exists( 'hap_esm_adapter_hap_studio_apply' ) ? 'hap_studio' : 'generic';
		}

		if ( 'hap_studio' === $mode ) {
			return self::serialize_hap_studio( $post );
		}
		return self::serialize_generic( $post );
	}

	/**
	 * @param string $post_type Post type.
	 * @param int    $limit Limit.
	 * @return array<int, array<string,mixed>>
	 */
	public static function example_posts( $post_type = 'post', $limit = 5 ) {
		$limit = max( 1, min( 10, (int) $limit ) );
		$q     = new WP_Query(
			array(
				'post_type'              => $post_type,
				'post_status'            => array( 'publish', 'draft' ),
				'posts_per_page'         => $limit,
				'orderby'                => 'modified',
				'order'                  => 'DESC',
				'no_found_rows'          => true,
				'update_post_meta_cache' => true,
				'update_post_term_cache' => true,
			)
		);
		$out = array();
		foreach ( $q->posts as $post ) {
			$doc = self::serialize_post( (int) $post->ID );
			if ( ! is_wp_error( $doc ) ) {
				$out[] = $doc;
			}
		}
		return $out;
	}

	/**
	 * Declared contract payload when ESM is present.
	 *
	 * @return array<string,mixed>|null
	 */
	public static function declared_contract() {
		if ( ! function_exists( 'hap_esm_studio_validate' ) || ! function_exists( 'hap_esm_adapter_hap_studio_apply' ) ) {
			return null;
		}
		return array(
			'profile'           => 'hap-studio-post-v1',
			'post_type'         => 'post',
			'label'             => 'Hap Studio — Post',
			'source'            => 'declared',
			'adapter'           => 'hap_esm_adapter_hap_studio_apply',
			'apply_mode'        => 'hap_studio',
			'serialize_version' => self::VERSION,
			'schema_hash'       => hash( 'sha256', 'hap-studio-post-v1:' . self::VERSION ),
			'field_roles'       => array(
				'title'              => array( 'role' => 'A', 'required' => true, 'ai_key' => 'title' ),
				'slug'               => array( 'role' => 'B', 'required' => true, 'crm_key' => 'slug' ),
				'hero.single_titolo' => array( 'role' => 'A', 'required' => true, 'ai_key' => 'h1' ),
				'hero.single_intro'  => array( 'role' => 'A', 'required' => true, 'ai_key' => 'intro' ),
				'sections'           => array( 'role' => 'A', 'required' => true, 'ai_key' => 'sections' ),
				'seo.title'          => array( 'role' => 'A', 'required' => true, 'ai_key' => 'seo_title' ),
				'seo.description'    => array( 'role' => 'A', 'required' => true, 'ai_key' => 'meta_description' ),
				'cta_preset'         => array( 'role' => 'B', 'required' => true, 'crm_key' => 'cta_preset' ),
			),
			'blueprint'         => array(
				'type'       => 'post',
				'slug'       => '{{CRM:slug}}',
				'title'      => '{{AI:title}}',
				'status'     => 'draft',
				'hero'       => array(
					'single_titolo' => '{{AI:h1}}',
					'single_intro'  => '{{AI:intro}}',
					'text_color'    => 'black',
					'overlay'       => false,
				),
				'seo'        => array(
					'title'         => '{{AI:seo_title}}',
					'description'   => '{{AI:meta_description}}',
					'focus_keyword' => '{{CRM:focus_keyword}}',
				),
				'sections'   => '{{AI:sections}}',
				'cta_preset' => '{{CRM:cta_preset}}',
			),
			'examples_count'    => 0,
		);
	}

	/**
	 * @param WP_Post $post Post.
	 * @return array<string,mixed>
	 */
	private static function serialize_hap_studio( $post ) {
		$id   = (int) $post->ID;
		$cats = array();
		foreach ( get_the_category( $id ) as $term ) {
			$cats[] = $term->slug;
		}
		$primary_slug = null;
		$primary_id   = (int) get_post_meta( $id, '_yoast_wpseo_primary_category', true );
		if ( $primary_id > 0 ) {
			$t = get_term( $primary_id, 'category' );
			if ( $t && ! is_wp_error( $t ) ) {
				$primary_slug = $t->slug;
			}
		}
		$text_color = (string) get_post_meta( $id, 'hap_hero_text_color', true );
		$overlay    = get_post_meta( $id, 'hap_hero_overlay', true );
		$teaser     = (string) get_post_meta( $id, 'hap_servizio_teaser', true );

		return array(
			'serialize_version' => self::VERSION,
			'apply_mode'        => 'hap_studio',
			'type'              => 'post',
			'id'                => $id,
			'slug'              => $post->post_name,
			'title'             => $post->post_title,
			'status'            => 'draft',
			'categories'        => $cats,
			'primary_category'  => $primary_slug,
			'featured_media_id' => (int) get_post_thumbnail_id( $id ) ?: null,
			'hero'              => array(
				'single_titolo' => (string) get_post_meta( $id, 'single_titolo', true ),
				'single_intro'  => (string) get_post_meta( $id, 'single_intro', true ),
				'text_color'    => in_array( $text_color, array( 'black', 'white' ), true ) ? $text_color : 'black',
				'overlay'       => ( '' === $overlay ) ? true : (bool) $overlay,
			),
			'seo'               => array(
				'title'         => (string) get_post_meta( $id, '_yoast_wpseo_title', true ),
				'description'   => (string) get_post_meta( $id, '_yoast_wpseo_metadesc', true ),
				'focus_keyword' => (string) get_post_meta( $id, '_yoast_wpseo_focuskw', true ),
			),
			'teaser'            => $teaser !== '' ? $teaser : null,
			'content_html'      => $post->post_content,
			'cta_preset'        => null,
			'_export'           => array(
				'permalink'    => get_permalink( $id ),
				'live_status'  => $post->post_status,
				'modified_gmt' => $post->post_modified_gmt,
			),
		);
	}

	/**
	 * Generic serialize for discovered contracts (meta_map / html_sections).
	 * Does not expand full Gutenberg block trees into editable blueprints.
	 *
	 * @param WP_Post $post Post.
	 * @return array<string,mixed>
	 */
	private static function serialize_generic( $post ) {
		$id = (int) $post->ID;
		$meta = array();
		$all  = get_post_meta( $id );
		foreach ( $all as $key => $values ) {
			if ( ! is_string( $key ) ) {
				continue;
			}
			if ( str_starts_with( $key, '_' ) && ! str_starts_with( $key, '_yoast_wpseo_' ) && ! str_starts_with( $key, '_thumbnail' ) ) {
				continue;
			}
			if ( in_array( $key, array( '_edit_lock', '_edit_last', '_encloseme' ), true ) ) {
				continue;
			}
			$raw = maybe_unserialize( $values[0] ?? '' );
			if ( is_string( $raw ) || is_numeric( $raw ) || is_bool( $raw ) ) {
				$meta[ $key ] = $raw;
			}
		}

		$has_blocks = function_exists( 'has_blocks' ) && has_blocks( $post->post_content );
		$seo_plugin = self::plugin_active( 'wordpress-seo/wp-seo.php' ) ? 'yoast' : ( self::plugin_active( 'seo-by-rank-math/rank-math.php' ) ? 'rank_math' : 'none' );

		$doc = array(
			'serialize_version' => self::VERSION,
			'apply_mode'        => $has_blocks ? 'html_sections' : 'meta_map',
			'type'              => $post->post_type,
			'id'                => $id,
			'slug'              => $post->post_name,
			'title'             => $post->post_title,
			'status'            => 'draft',
			'featured_media_id' => (int) get_post_thumbnail_id( $id ) ?: null,
			'content_html'      => $has_blocks ? '' : $post->post_content,
			'has_blocks'        => $has_blocks,
			'seo_plugin'        => $seo_plugin,
			'meta'              => $meta,
			'_export'           => array(
				'permalink'    => get_permalink( $id ),
				'live_status'  => $post->post_status,
				'modified_gmt' => $post->post_modified_gmt,
				'note'         => $has_blocks
					? 'Gutenberg/ACF blocks detected — full block blueprint not auto-generated in MVP.'
					: '',
			),
		);

		if ( 'yoast' === $seo_plugin ) {
			$doc['seo'] = array(
				'title'         => (string) get_post_meta( $id, '_yoast_wpseo_title', true ),
				'description'   => (string) get_post_meta( $id, '_yoast_wpseo_metadesc', true ),
				'focus_keyword' => (string) get_post_meta( $id, '_yoast_wpseo_focuskw', true ),
			);
		} elseif ( 'rank_math' === $seo_plugin ) {
			$doc['seo'] = array(
				'title'         => (string) get_post_meta( $id, 'rank_math_title', true ),
				'description'   => (string) get_post_meta( $id, 'rank_math_description', true ),
				'focus_keyword' => (string) get_post_meta( $id, 'rank_math_focus_keyword', true ),
			);
		}

		return $doc;
	}

	/**
	 * @param string $plugin Plugin file.
	 */
	private static function plugin_active( $plugin ) {
		if ( ! function_exists( 'is_plugin_active' ) ) {
			require_once ABSPATH . 'wp-admin/includes/plugin.php';
		}
		return function_exists( 'is_plugin_active' ) ? is_plugin_active( $plugin ) : false;
	}
}
