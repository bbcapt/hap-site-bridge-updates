<?php
/**
 * POST /wp-json/hap/v1/content/draft
 *
 * Body: Hap article JSON contract (article.schema.json).
 * Auth: Application Password (user with edit_posts) OR X-Hap-Bridge-Write-Key header.
 * Never publishes — only draft/pending.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Hap_Bridge_Rest_Draft {

	public function register() {
		register_rest_route(
			'hap/v1',
			'/content/draft',
			array(
				'methods'             => 'POST',
				'callback'            => array( $this, 'handle' ),
				'permission_callback' => array( $this, 'permission' ),
			)
		);
	}

	/**
	 * @param WP_REST_Request $request Request.
	 * @return bool|WP_Error
	 */
	public function permission( $request ) {
		$write_key = hap_site_bridge_write_key();
		$header    = (string) $request->get_header( 'x_hap_bridge_write_key' );
		if ( '' === $header ) {
			$header = (string) $request->get_header( 'X-Hap-Bridge-Write-Key' );
		}
		if ( $write_key && $header && hash_equals( $write_key, $header ) ) {
			return true;
		}
		if ( is_user_logged_in() && current_user_can( 'edit_posts' ) ) {
			return true;
		}
		return new WP_Error( 'hap_bridge_forbidden', 'Write auth required (Application Password or write key).', array( 'status' => 403 ) );
	}

	/**
	 * @param WP_REST_Request $request Request.
	 * @return WP_REST_Response|WP_Error
	 */
	public function handle( $request ) {
		$data = $request->get_json_params();
		if ( ! is_array( $data ) ) {
			return new WP_Error( 'hap_bridge_invalid', 'JSON body required.', array( 'status' => 400 ) );
		}

		$slug  = isset( $data['slug'] ) ? sanitize_title( (string) $data['slug'] ) : '';
		$title = isset( $data['title'] ) ? sanitize_text_field( (string) $data['title'] ) : '';
		if ( '' === $slug || '' === $title ) {
			return new WP_Error( 'hap_bridge_invalid', 'slug and title are required.', array( 'status' => 400 ) );
		}

		$status = isset( $data['status'] ) ? (string) $data['status'] : 'draft';
		if ( ! in_array( $status, array( 'draft', 'pending' ), true ) ) {
			$status = 'draft';
		}

		$html = $this->compile_html( $data );
		if ( '' === $html ) {
			return new WP_Error( 'hap_bridge_invalid', 'Empty content: provide content_html or sections.', array( 'status' => 400 ) );
		}

		$post_id = isset( $data['id'] ) ? (int) $data['id'] : 0;
		if ( $post_id <= 0 ) {
			$existing = get_page_by_path( $slug, OBJECT, 'post' );
			if ( $existing ) {
				$post_id = (int) $existing->ID;
			}
		}

		$postarr = array(
			'post_type'    => 'post',
			'post_title'   => $title,
			'post_name'    => $slug,
			'post_content' => $html,
			'post_status'  => $status,
		);

		if ( $post_id > 0 ) {
			$current = get_post( $post_id );
			if ( ! $current || 'post' !== $current->post_type ) {
				return new WP_Error( 'hap_bridge_invalid', 'Post not found.', array( 'status' => 404 ) );
			}
			$postarr['ID'] = $post_id;
			if ( 'publish' === $current->post_status ) {
				unset( $postarr['post_status'] );
			}
			$result = wp_update_post( $postarr, true );
		} else {
			$result = wp_insert_post( $postarr, true );
		}

		if ( is_wp_error( $result ) ) {
			return $result;
		}
		$post_id = (int) $result;

		$cat_slugs = isset( $data['categories'] ) && is_array( $data['categories'] ) ? $data['categories'] : array();
		$cat_ids   = $this->category_ids( $cat_slugs );
		if ( $cat_ids ) {
			wp_set_post_categories( $post_id, $cat_ids, false );
		}

		$primary_slug = isset( $data['primary_category'] ) ? sanitize_title( (string) $data['primary_category'] ) : '';
		if ( '' !== $primary_slug ) {
			$primary = get_term_by( 'slug', $primary_slug, 'category' );
			if ( $primary && ! is_wp_error( $primary ) ) {
				update_post_meta( $post_id, '_yoast_wpseo_primary_category', (string) (int) $primary->term_id );
			}
		}

		$profile = isset( $data['profile'] ) ? sanitize_key( (string) $data['profile'] ) : 'hap-studio';
		if ( 'hap-studio' === $profile ) {
			$this->apply_hap_studio_meta( $post_id, $data, $cat_slugs );
		}

		$seo   = isset( $data['seo'] ) && is_array( $data['seo'] ) ? $data['seo'] : array();
		$st    = isset( $seo['title'] ) ? (string) $seo['title'] : $title;
		$st    = $this->brand_title( $st );
		$sd    = isset( $seo['description'] ) ? (string) $seo['description'] : '';
		$sf    = isset( $seo['focus_keyword'] ) ? sanitize_text_field( (string) $seo['focus_keyword'] ) : '';
		if ( '' === $sd ) {
			$sd = wp_trim_words( wp_strip_all_tags( $html ), 22, '…' );
		}
		update_post_meta( $post_id, '_yoast_wpseo_title', $st );
		update_post_meta( $post_id, '_yoast_wpseo_metadesc', $sd );
		if ( '' !== $sf ) {
			update_post_meta( $post_id, '_yoast_wpseo_focuskw', $sf );
		}

		$media = isset( $data['featured_media_id'] ) ? (int) $data['featured_media_id'] : 0;
		if ( $media > 0 ) {
			set_post_thumbnail( $post_id, $media );
		}

		return new WP_REST_Response(
			array(
				'ok'       => true,
				'post_id'  => $post_id,
				'status'   => get_post_status( $post_id ),
				'slug'     => $slug,
				'edit_url' => admin_url( 'post.php?post=' . $post_id . '&action=edit' ),
				'view_url' => get_permalink( $post_id ),
			),
			200
		);
	}

	/**
	 * @param array<string,mixed> $data Contract.
	 * @return string
	 */
	private function compile_html( array $data ) {
		if ( ! empty( $data['content_html'] ) && is_string( $data['content_html'] ) ) {
			return trim( wp_kses_post( $data['content_html'] ) );
		}
		$html     = '';
		$sections = isset( $data['sections'] ) && is_array( $data['sections'] ) ? $data['sections'] : array();
		foreach ( $sections as $section ) {
			if ( ! is_array( $section ) ) {
				continue;
			}
			$anchor  = isset( $section['anchor'] ) ? sanitize_title( (string) $section['anchor'] ) : '';
			$heading = isset( $section['heading'] ) ? (string) $section['heading'] : '';
			if ( '' === $anchor || '' === $heading ) {
				continue;
			}
			$html .= '<h2 id="' . esc_attr( $anchor ) . '">' . esc_html( $heading ) . "</h2>\n";
			$paras = isset( $section['paragraphs'] ) && is_array( $section['paragraphs'] ) ? $section['paragraphs'] : array();
			foreach ( $paras as $p ) {
				$p = trim( (string) $p );
				if ( '' === $p ) {
					continue;
				}
				$p = wp_kses_post( $p );
				if ( ! preg_match( '/^\s*</', $p ) ) {
					$p = '<p>' . $p . '</p>';
				}
				$html .= $p . "\n";
			}
		}
		return trim( $html );
	}

	/**
	 * @param string[] $slugs Category slugs.
	 * @return int[]
	 */
	private function category_ids( array $slugs ) {
		$ids = array();
		foreach ( $slugs as $slug ) {
			$slug = sanitize_title( (string) $slug );
			if ( '' === $slug ) {
				continue;
			}
			$term = get_term_by( 'slug', $slug, 'category' );
			if ( $term && ! is_wp_error( $term ) ) {
				$ids[] = (int) $term->term_id;
				continue;
			}
			$created = wp_insert_term( ucwords( str_replace( '-', ' ', $slug ) ), 'category', array( 'slug' => $slug ) );
			if ( ! is_wp_error( $created ) && isset( $created['term_id'] ) ) {
				$ids[] = (int) $created['term_id'];
			}
		}
		return array_values( array_unique( array_filter( $ids ) ) );
	}

	/**
	 * @param string $title Title.
	 * @return string
	 */
	private function brand_title( $title ) {
		$title = trim( (string) $title );
		$title = preg_replace( '/\s*[\|\-–—]\s*Hap Studio\s*$/i', '', $title );
		$title = trim( (string) $title, " \t|-–—" );
		if ( '' === $title ) {
			return 'Hap Studio';
		}
		return $title . ' | Hap Studio';
	}

	/**
	 * Hap Studio servizi single meta (safe if ACF missing).
	 *
	 * @param int                 $post_id Post ID.
	 * @param array<string,mixed> $data    Contract.
	 * @param string[]            $cat_slugs Categories.
	 */
	private function apply_hap_studio_meta( $post_id, array $data, array $cat_slugs ) {
		$areas   = array( 'sito-web', 'servizi-seo', 'pubblicita-google', 'gestione-digitale' );
		$is_area = false;
		foreach ( $cat_slugs as $s ) {
			if ( in_array( sanitize_title( (string) $s ), $areas, true ) ) {
				$is_area = true;
				break;
			}
		}
		if ( $is_area ) {
			update_post_meta( $post_id, 'hap_is_servizio', '1' );
			if ( function_exists( 'update_field' ) ) {
				update_field( 'hap_is_servizio', 1, $post_id );
			}
		}

		$hero = isset( $data['hero'] ) && is_array( $data['hero'] ) ? $data['hero'] : array();
		if ( ! empty( $hero['single_titolo'] ) ) {
			$v = sanitize_text_field( (string) $hero['single_titolo'] );
			update_post_meta( $post_id, 'single_titolo', $v );
			if ( function_exists( 'update_field' ) ) {
				update_field( 'single_titolo', $v, $post_id );
			}
		}
		if ( isset( $hero['single_intro'] ) ) {
			$v = sanitize_textarea_field( (string) $hero['single_intro'] );
			update_post_meta( $post_id, 'single_intro', $v );
			if ( function_exists( 'update_field' ) ) {
				update_field( 'single_intro', $v, $post_id );
			}
		}
		if ( ! empty( $data['teaser'] ) ) {
			$t = sanitize_textarea_field( (string) $data['teaser'] );
			update_post_meta( $post_id, 'hap_servizio_teaser', $t );
			if ( function_exists( 'update_field' ) ) {
				update_field( 'hap_servizio_teaser', $t, $post_id );
			}
		}
		if ( ! empty( $data['cta_preset'] ) ) {
			update_post_meta( $post_id, 'cta_preset', sanitize_key( (string) $data['cta_preset'] ) );
		}
	}
}
