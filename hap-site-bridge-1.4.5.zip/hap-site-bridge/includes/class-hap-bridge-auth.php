<?php
/**
 * HAP Bridge v1 auth: Ed25519 signed requests + short-lived sessions.
 *
 * @package HapSiteBridge
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Security gateway helpers.
 */
class Hap_Bridge_Auth {

	public const PROTOCOL        = 'HAP-BRIDGE-1';
	public const TIMESTAMP_SLOP  = 300;
	public const SESSION_DEFAULT = 600;

	/**
	 * @return true|WP_Error
	 */
	public static function require_https() {
		if ( is_ssl() ) {
			return true;
		}
		// Behind reverse proxy (SiteGround).
		if ( ! empty( $_SERVER['HTTP_X_FORWARDED_PROTO'] ) && 'https' === strtolower( (string) $_SERVER['HTTP_X_FORWARDED_PROTO'] ) ) {
			return true;
		}
		return new WP_Error( 'hap_bridge_https_required', 'HTTPS required.', array( 'status' => 403 ) );
	}

	/**
	 * @param string $method HTTP method.
	 * @param string $path   REST path (e.g. /wp-json/hap-bridge/v1/session/open).
	 * @param string $connection_id Connection id.
	 * @param string $site_id Site id.
	 * @param string $timestamp Unix string.
	 * @param string $nonce Nonce.
	 * @param string $scope Scope string.
	 * @param string $body_hash SHA256 hex of body.
	 * @return string
	 */
	public static function canonical_string( $method, $path, $connection_id, $site_id, $timestamp, $nonce, $scope, $body_hash ) {
		$parts = array(
			self::PROTOCOL,
			strtoupper( (string) $method ),
			(string) $path,
			(string) $connection_id,
			(string) $site_id,
			(string) $timestamp,
			(string) $nonce,
			(string) $scope,
			(string) $body_hash,
		);
		return implode( "\n", $parts );
	}

	/**
	 * @param WP_REST_Request $request Request.
	 * @param string          $scope Expected scope for signed request (empty if N/A).
	 * @return true|WP_Error
	 */
	public static function verify_signed_request( WP_REST_Request $request, $scope = '' ) {
		$https = self::require_https();
		if ( is_wp_error( $https ) ) {
			return $https;
		}

		if ( ! Hap_Bridge_Connection::is_paired() ) {
			return new WP_Error( 'hap_bridge_not_paired', 'Site not paired with CRM.', array( 'status' => 503 ) );
		}

		$conn = Hap_Bridge_Connection::get();
		if ( $conn['revoked'] ) {
			return new WP_Error( 'hap_bridge_revoked', 'Connection revoked.', array( 'status' => 403 ) );
		}

		$connection_id = (string) $request->get_header( 'x_hap_connection_id' );
		if ( '' === $connection_id ) {
			$connection_id = (string) $request->get_header( 'X-Hap-Connection-Id' );
		}
		$key_id = (string) $request->get_header( 'x_hap_key_id' );
		if ( '' === $key_id ) {
			$key_id = (string) $request->get_header( 'X-Hap-Key-Id' );
		}
		if ( '' === $key_id ) {
			$key_id = 'k1';
		}
		$timestamp = (string) $request->get_header( 'x_hap_timestamp' );
		if ( '' === $timestamp ) {
			$timestamp = (string) $request->get_header( 'X-Hap-Timestamp' );
		}
		$nonce = (string) $request->get_header( 'x_hap_nonce' );
		if ( '' === $nonce ) {
			$nonce = (string) $request->get_header( 'X-Hap-Nonce' );
		}
		$signature = (string) $request->get_header( 'x_hap_signature' );
		if ( '' === $signature ) {
			$signature = (string) $request->get_header( 'X-Hap-Signature' );
		}

		if ( '' === $connection_id || '' === $timestamp || '' === $nonce || '' === $signature ) {
			return new WP_Error( 'hap_bridge_auth_headers', 'Missing HAP auth headers.', array( 'status' => 401 ) );
		}

		if ( ! hash_equals( $conn['connection_id'], $connection_id ) ) {
			return new WP_Error( 'hap_bridge_connection_mismatch', 'Invalid connection.', array( 'status' => 403 ) );
		}

		$ts = (int) $timestamp;
		if ( $ts <= 0 || abs( time() - $ts ) > self::TIMESTAMP_SLOP ) {
			return new WP_Error( 'hap_bridge_timestamp', 'Timestamp out of window.', array( 'status' => 401 ) );
		}

		if ( ! self::consume_nonce( $connection_id, $nonce ) ) {
			return new WP_Error( 'hap_bridge_nonce_replay', 'Nonce already used.', array( 'status' => 401 ) );
		}

		$body      = $request->get_body();
		$body_hash = hash( 'sha256', (string) $body );
		$path      = self::request_path( $request );
		$canonical = self::canonical_string(
			$request->get_method(),
			$path,
			$connection_id,
			$conn['site_id'],
			$timestamp,
			$nonce,
			$scope,
			$body_hash
		);

		$pub = Hap_Bridge_Connection::public_key_for( $key_id );
		if ( '' === $pub ) {
			return new WP_Error( 'hap_bridge_unknown_key', 'Unknown key id.', array( 'status' => 403 ) );
		}

		if ( ! function_exists( 'sodium_crypto_sign_verify_detached' ) ) {
			return new WP_Error( 'hap_bridge_no_sodium', 'Ed25519 not available.', array( 'status' => 503 ) );
		}

		$sig_bin = base64_decode( $signature, true );
		if ( false === $sig_bin ) {
			return new WP_Error( 'hap_bridge_bad_signature', 'Invalid signature encoding.', array( 'status' => 401 ) );
		}

		$ok = sodium_crypto_sign_verify_detached( $sig_bin, $canonical, $pub );
		if ( ! $ok ) {
			return new WP_Error( 'hap_bridge_bad_signature', 'Signature verification failed.', array( 'status' => 401 ) );
		}

		return true;
	}

	/**
	 * @param WP_REST_Request $request Request.
	 * @param string          $scope Required scope.
	 * @return true|WP_Error
	 */
	public static function authorize( WP_REST_Request $request, $scope ) {
		$token = (string) $request->get_header( 'x_hap_session_token' );
		if ( '' === $token ) {
			$token = (string) $request->get_header( 'X-Hap-Session-Token' );
		}
		if ( '' !== $token ) {
			return Hap_Bridge_Session::authorize_token( $token, $scope, $request );
		}
		return self::verify_signed_request( $request, $scope );
	}

	/**
	 * @param WP_REST_Request $request Request.
	 * @return string
	 */
	public static function request_path( WP_REST_Request $request ) {
		$route = $request->get_route();
		return '/wp-json' . (string) $route;
	}

	/**
	 * @param string $connection_id Connection.
	 * @param string $nonce Nonce.
	 * @return bool True if accepted.
	 */
	public static function consume_nonce( $connection_id, $nonce ) {
		if ( strlen( $nonce ) < 16 ) {
			return false;
		}
		$key = 'hap_bn_' . hash( 'sha256', $connection_id . '|' . $nonce );
		if ( get_transient( $key ) ) {
			return false;
		}
		set_transient( $key, 1, self::TIMESTAMP_SLOP * 2 );
		return true;
	}

	/**
	 * @param string $scopes Comma-separated scopes.
	 * @return string Normalized.
	 */
	public static function normalize_scopes( $scopes ) {
		$list = array_map( 'trim', explode( ',', (string) $scopes ) );
		$list = array_filter( $list );
		sort( $list );
		return implode( ',', $list );
	}
}
