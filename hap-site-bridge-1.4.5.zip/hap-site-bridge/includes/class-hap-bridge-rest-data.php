<?php
/**
 * GET /wp-json/hap/v1/data/?api-key=...
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Hap_Bridge_Rest_Data {

	public function register() {
		register_rest_route(
			'hap/v1',
			'/data',
			array(
				'methods'             => 'GET',
				'callback'            => array( $this, 'handle' ),
				'permission_callback' => array( $this, 'permission' ),
			)
		);
	}

	/**
	 * @param WP_REST_Request $request Request.
	 * @return bool|WP_Error
	 */
	public function permission( $request ) {
		$expected = hap_site_bridge_api_key();
		if ( '' === $expected ) {
			return new WP_Error( 'hap_bridge_unconfigured', 'API key not configured on site.', array( 'status' => 503 ) );
		}
		$got = (string) $request->get_param( 'api-key' );
		if ( ! hash_equals( $expected, $got ) ) {
			return new WP_Error( 'hap_bridge_forbidden', 'Invalid api-key.', array( 'status' => 403 ) );
		}
		return true;
	}

	/**
	 * @param WP_REST_Request $request Request.
	 * @return WP_REST_Response
	 */
	public function handle( $request ) {
		$collector = new Hap_Bridge_Collector();
		$version   = (string) $request->get_param( 'v' );
		$slots_param = (string) $request->get_param( 'slots' );

		if ( $slots_param !== '' ) {
			$plain = $collector->build_plain_slots();
			$wanted = array_map( 'intval', preg_split( '/\s*,\s*/', $slots_param ) );
			$filtered = array();
			foreach ( $wanted as $idx ) {
				if ( isset( $plain[ $idx ] ) ) {
					$filtered[ $idx ] = Hap_Bridge_Crypto::encrypt_list( $plain[ $idx ] );
				}
			}
			$response = array(
				'bridge_version' => defined( 'HAP_SITE_BRIDGE_VERSION' ) ? HAP_SITE_BRIDGE_VERSION : '1',
				'payload_version'=> $version !== '' ? $version : 'subset',
				'slots'          => $filtered,
			);
			return new WP_REST_Response( $response, 200 );
		}

		$slots = $collector->build_encrypted_slots();
		// Default: CRM legacy expects a JSON array of encrypted slot lists.
		return new WP_REST_Response( $slots, 200 );
	}
}
