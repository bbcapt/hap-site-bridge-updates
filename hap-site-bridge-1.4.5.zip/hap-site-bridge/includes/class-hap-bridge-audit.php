<?php
/**
 * Minimal audit log (ring buffer in option).
 *
 * @package HapSiteBridge
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Audit entries.
 */
class Hap_Bridge_Audit {

	const OPTION = 'hap_bridge_audit_log';
	const MAX    = 200;

	/**
	 * @param array<string,mixed> $row Row.
	 */
	public static function log( array $row ) {
		$row['ts'] = gmdate( 'c' );
		$log       = get_option( self::OPTION, array() );
		if ( ! is_array( $log ) ) {
			$log = array();
		}
		array_unshift( $log, $row );
		$log = array_slice( $log, 0, self::MAX );
		update_option( self::OPTION, $log, false );
	}
}
