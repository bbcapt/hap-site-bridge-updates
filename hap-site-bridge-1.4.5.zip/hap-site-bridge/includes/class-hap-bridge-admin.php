<?php
/**
 * Admin settings UI — save / clear API key and unpair analysis without wp-config.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Hap_Bridge_Admin {

	const OPTION_API_KEY            = 'hap_site_bridge_api_key';
	const OPTION_WRITE_KEY          = 'hap_site_bridge_write_key';
	const OPTION_ANALYSIS_DISABLED  = 'hap_site_bridge_analysis_disabled';
	const PAGE_SLUG                 = 'hap-site-bridge';

	public static function init() {
		add_action( 'admin_menu', array( __CLASS__, 'register_menu' ) );
		add_filter( 'plugin_action_links_' . plugin_basename( HAP_SITE_BRIDGE_FILE ), array( __CLASS__, 'action_links' ) );
	}

	/**
	 * @param array<int,string> $links Links.
	 * @return array<int,string>
	 */
	public static function action_links( $links ) {
		$url = admin_url( 'options-general.php?page=' . self::PAGE_SLUG );
		array_unshift(
			$links,
			'<a href="' . esc_url( $url ) . '">' . esc_html__( 'Settings', 'hap-site-bridge' ) . '</a>'
		);
		return $links;
	}

	public static function register_menu() {
		add_options_page(
			__( 'Hap Site Bridge', 'hap-site-bridge' ),
			__( 'Hap Bridge', 'hap-site-bridge' ),
			'manage_options',
			self::PAGE_SLUG,
			array( __CLASS__, 'render_page' )
		);
	}

	public static function render_page() {
		if ( ! current_user_can( 'manage_options' ) ) {
			return;
		}

		$notice = '';
		if (
			isset( $_POST['hap_bridge_settings_nonce'] )
			&& wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['hap_bridge_settings_nonce'] ) ), 'hap_bridge_save_settings' )
		) {
			$notice = self::save_posted();
		}

		$api_locked   = defined( 'HAP_SITE_BRIDGE_API_KEY' ) && HAP_SITE_BRIDGE_API_KEY;
		$write_locked = defined( 'HAP_SITE_BRIDGE_WRITE_KEY' ) && HAP_SITE_BRIDGE_WRITE_KEY;
		$api_set      = hap_site_bridge_api_key() !== '';
		$write_set    = hap_site_bridge_write_key() !== '';
		$v2_paired    = Hap_Bridge_Connection::is_paired();
		$v2_locked    = Hap_Bridge_Connection::is_locked_by_constants();
		$disabled     = hap_site_bridge_analysis_disabled();
		// Configured in wp-config/option even if soft-unpaired.
		$api_present  = $api_locked || (string) get_option( self::OPTION_API_KEY, '' ) !== '';
		?>
		<div class="wrap">
			<h1><?php esc_html_e( 'Hap Site Bridge', 'hap-site-bridge' ); ?></h1>
			<p><?php esc_html_e( 'Paste the same read API key stored in HAP OS (Sites → Hap Bridge → Credentials). No wp-config edit required.', 'hap-site-bridge' ); ?></p>

			<?php if ( $notice ) : ?>
				<div class="notice notice-success is-dismissible"><p><?php echo esc_html( $notice ); ?></p></div>
			<?php endif; ?>

			<?php if ( $disabled && $api_locked ) : ?>
				<div class="notice notice-warning">
					<p><?php esc_html_e( 'Analysis is unpaired from this screen, but HAP_SITE_BRIDGE_API_KEY is still in wp-config. Remove that constant when you can (cleanup). Re-pair from HAP OS anytime.', 'hap-site-bridge' ); ?></p>
				</div>
			<?php endif; ?>

			<form method="post">
				<?php wp_nonce_field( 'hap_bridge_save_settings', 'hap_bridge_settings_nonce' ); ?>
				<table class="form-table" role="presentation">
					<tr>
						<th scope="row">
							<label for="hap_site_bridge_api_key"><?php esc_html_e( 'Read API key', 'hap-site-bridge' ); ?></label>
						</th>
						<td>
							<?php if ( $api_locked && ! $disabled ) : ?>
								<input type="text" class="regular-text" value="<?php esc_attr_e( 'Set in wp-config (HAP_SITE_BRIDGE_API_KEY)', 'hap-site-bridge' ); ?>" disabled />
								<p class="description"><?php esc_html_e( 'Legacy wp-config constant is active. Use “Unpair analysis” below — no need to edit wp-config first.', 'hap-site-bridge' ); ?></p>
							<?php elseif ( $api_locked && $disabled ) : ?>
								<input type="text" class="regular-text" value="<?php esc_attr_e( 'Unpaired (wp-config constant ignored)', 'hap-site-bridge' ); ?>" disabled />
								<p class="description"><?php esc_html_e( 'Click Re-enable analysis below, or remove HAP_SITE_BRIDGE_API_KEY from wp-config and paste a key from HAP OS.', 'hap-site-bridge' ); ?></p>
							<?php else : ?>
								<input
									type="password"
									class="regular-text"
									id="hap_site_bridge_api_key"
									name="hap_site_bridge_api_key"
									value=""
									autocomplete="new-password"
									placeholder="<?php echo $api_set ? esc_attr__( '•••• saved — paste to replace', 'hap-site-bridge' ) : esc_attr__( 'Paste API key from HAP OS', 'hap-site-bridge' ); ?>"
								/>
								<p class="description">
									<?php
									echo $api_set
										? esc_html__( 'A key is already saved. Leave blank to keep it, or paste a new one to replace.', 'hap-site-bridge' )
										: esc_html__( 'Required for HAP OS site analysis (GET hap/v1/data).', 'hap-site-bridge' );
									?>
								</p>
								<?php if ( $api_set ) : ?>
									<p>
										<label>
											<input type="checkbox" name="hap_bridge_clear_api_key" value="1" />
											<?php esc_html_e( 'Clear read API key (unpair analysis channel)', 'hap-site-bridge' ); ?>
										</label>
									</p>
								<?php endif; ?>
							<?php endif; ?>
						</td>
					</tr>
					<tr>
						<th scope="row">
							<label for="hap_site_bridge_write_key"><?php esc_html_e( 'Write key (optional)', 'hap-site-bridge' ); ?></label>
						</th>
						<td>
							<?php if ( $write_locked ) : ?>
								<input type="text" class="regular-text" value="<?php esc_attr_e( 'Set in wp-config (HAP_SITE_BRIDGE_WRITE_KEY)', 'hap-site-bridge' ); ?>" disabled />
							<?php else : ?>
								<input
									type="password"
									class="regular-text"
									id="hap_site_bridge_write_key"
									name="hap_site_bridge_write_key"
									value=""
									autocomplete="new-password"
									placeholder="<?php echo $write_set ? esc_attr__( '•••• saved — paste to replace', 'hap-site-bridge' ) : esc_attr__( 'Optional', 'hap-site-bridge' ); ?>"
								/>
								<p class="description"><?php esc_html_e( 'Only for legacy draft write. Leave empty if unused.', 'hap-site-bridge' ); ?></p>
								<?php if ( $write_set ) : ?>
									<p>
										<label>
											<input type="checkbox" name="hap_bridge_clear_write_key" value="1" />
											<?php esc_html_e( 'Clear write key', 'hap-site-bridge' ); ?>
										</label>
									</p>
								<?php endif; ?>
							<?php endif; ?>
						</td>
					</tr>
					<tr>
						<th scope="row"><?php esc_html_e( 'Status', 'hap-site-bridge' ); ?></th>
						<td>
							<p>
								<strong><?php esc_html_e( 'Version', 'hap-site-bridge' ); ?>:</strong>
								<?php echo esc_html( HAP_SITE_BRIDGE_VERSION ); ?>
							</p>
							<p>
								<strong><?php esc_html_e( 'Analysis (read API key)', 'hap-site-bridge' ); ?>:</strong>
								<?php echo $api_set ? esc_html__( 'configured', 'hap-site-bridge' ) : esc_html__( 'missing — HAP OS will show Unpaired', 'hap-site-bridge' ); ?>
							</p>
							<p>
								<strong><?php esc_html_e( 'v2 connection', 'hap-site-bridge' ); ?>:</strong>
								<?php echo $v2_paired ? esc_html__( 'paired', 'hap-site-bridge' ) : esc_html__( 'not paired', 'hap-site-bridge' ); ?>
							</p>
							<p>
								<strong><?php esc_html_e( 'Update channel', 'hap-site-bridge' ); ?>:</strong>
								<code style="word-break:break-all;"><?php echo esc_html( hap_site_bridge_update_json_url() ); ?></code>
							</p>
						</td>
					</tr>
				</table>
				<?php submit_button( __( 'Save settings', 'hap-site-bridge' ) ); ?>
			</form>

			<hr />
			<h2><?php esc_html_e( 'Unpair', 'hap-site-bridge' ); ?></h2>
			<p class="description"><?php esc_html_e( 'Use these to test HAP OS Unpaired state. Then open Sites → Connector and run Pairing Bridge.', 'hap-site-bridge' ); ?></p>

			<?php if ( $api_set || ( $api_present && ! $disabled ) ) : ?>
				<form method="post" style="margin: 1em 0;" onsubmit="return confirm('<?php echo esc_js( __( 'Unpair analysis? HAP OS will see Unpaired and stop reading site analysis.', 'hap-site-bridge' ) ); ?>');">
					<?php wp_nonce_field( 'hap_bridge_save_settings', 'hap_bridge_settings_nonce' ); ?>
					<input type="hidden" name="hap_bridge_action" value="unpair_analysis" />
					<?php submit_button( __( 'Unpair analysis (clear / disable read API key)', 'hap-site-bridge' ), 'delete', 'submit', false ); ?>
				</form>
			<?php elseif ( $disabled && $api_locked ) : ?>
				<form method="post" style="margin: 1em 0;">
					<?php wp_nonce_field( 'hap_bridge_save_settings', 'hap_bridge_settings_nonce' ); ?>
					<input type="hidden" name="hap_bridge_action" value="reenable_analysis" />
					<?php submit_button( __( 'Re-enable analysis (use wp-config key again)', 'hap-site-bridge' ), 'secondary', 'submit', false ); ?>
				</form>
			<?php endif; ?>

			<?php if ( $v2_paired ) : ?>
				<form method="post" style="margin: 1em 0;" onsubmit="return confirm('<?php echo esc_js( __( 'Unpair v2 connection on this site?', 'hap-site-bridge' ) ); ?>');">
					<?php wp_nonce_field( 'hap_bridge_save_settings', 'hap_bridge_settings_nonce' ); ?>
					<input type="hidden" name="hap_bridge_action" value="unpair_v2" />
					<?php submit_button( __( 'Unpair v2 connection', 'hap-site-bridge' ), 'delete', 'submit', false ); ?>
					<?php if ( $v2_locked ) : ?>
						<p class="description"><?php esc_html_e( 'v2 constants in wp-config (HAP_BRIDGE_CONNECTION_ID / SITE_ID / CRM_PUBLIC_KEY) override stored pairing — remove them if Unpair does not stick.', 'hap-site-bridge' ); ?></p>
					<?php endif; ?>
				</form>
			<?php endif; ?>
		</div>
		<?php
	}

	/**
	 * @return string Notice text.
	 */
	private static function save_posted() {
		if ( ! current_user_can( 'manage_options' ) ) {
			return '';
		}

		$action = isset( $_POST['hap_bridge_action'] ) ? sanitize_text_field( wp_unslash( $_POST['hap_bridge_action'] ) ) : '';

		if ( 'unpair_v2' === $action ) {
			$ok = Hap_Bridge_Connection::unpair();
			if ( $ok ) {
				return __( 'v2 connection unpaired on this site.', 'hap-site-bridge' );
			}
			return __( 'v2 still paired — remove HAP_BRIDGE_* constants from wp-config, then try again.', 'hap-site-bridge' );
		}

		if ( 'reenable_analysis' === $action ) {
			delete_option( self::OPTION_ANALYSIS_DISABLED );
			return __( 'Analysis re-enabled (wp-config / saved key active again).', 'hap-site-bridge' );
		}

		if ( 'unpair_analysis' === $action || ! empty( $_POST['hap_bridge_clear_api_key'] ) ) {
			delete_option( self::OPTION_API_KEY );
			// Soft-unpair so wp-config HAP_SITE_BRIDGE_API_KEY no longer feeds analysis.
			update_option( self::OPTION_ANALYSIS_DISABLED, '1', false );
			return __( 'Analysis unpaired. HAP OS will report Unpaired after the next Bridge verify. (wp-config constant, if present, is ignored until you Re-enable.)', 'hap-site-bridge' );
		}

		// Saving a new key from the form re-enables analysis.
		if ( ! ( defined( 'HAP_SITE_BRIDGE_API_KEY' ) && HAP_SITE_BRIDGE_API_KEY ) ) {
			$api = isset( $_POST['hap_site_bridge_api_key'] ) ? trim( (string) wp_unslash( $_POST['hap_site_bridge_api_key'] ) ) : '';
			if ( $api !== '' ) {
				update_option( self::OPTION_API_KEY, $api, false );
				delete_option( self::OPTION_ANALYSIS_DISABLED );
			}
		}

		if ( ! ( defined( 'HAP_SITE_BRIDGE_WRITE_KEY' ) && HAP_SITE_BRIDGE_WRITE_KEY ) ) {
			if ( ! empty( $_POST['hap_bridge_clear_write_key'] ) ) {
				delete_option( self::OPTION_WRITE_KEY );
			} else {
				$write = isset( $_POST['hap_site_bridge_write_key'] ) ? trim( (string) wp_unslash( $_POST['hap_site_bridge_write_key'] ) ) : '';
				if ( $write !== '' ) {
					update_option( self::OPTION_WRITE_KEY, $write, false );
				}
			}
		}

		return __( 'Settings saved.', 'hap-site-bridge' );
	}
}
