<?php
/**
 * Deployment idempotency store.
 *
 * @package HapSiteBridge
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Remember completed deployments.
 */
class Hap_Bridge_Idempotency {

	const TTL = 7776000; // 90 days.

	/**
	 * @param string $connection_id Connection.
	 * @param string $deployment_id Deployment id.
	 * @return array<string,mixed>|null
	 */
	public static function get( $connection_id, $deployment_id ) {
		$key = self::key( $connection_id, $deployment_id );
		$val = get_option( $key, null );
		return is_array( $val ) ? $val : null;
	}

	/**
	 * @param string               $connection_id Connection.
	 * @param string               $deployment_id Deployment.
	 * @param array<string,mixed>  $ack Ack payload.
	 */
	public static function put( $connection_id, $deployment_id, array $ack ) {
		$key = self::key( $connection_id, $deployment_id );
		update_option( $key, $ack, false );
	}

	/**
	 * @param string $connection_id Connection.
	 * @param string $deployment_id Deployment.
	 * @return string
	 */
	private static function key( $connection_id, $deployment_id ) {
		return 'hap_deploy_' . hash( 'sha256', $connection_id . '|' . $deployment_id );
	}
}
