<?php
/**
 * Editorial deploy via ESM (hap-studio) or generic apply modes.
 *
 * @package HapSiteBridge
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Apply deployment payload to WordPress.
 */
class Hap_Bridge_Editorial {

	/**
	 * @param array<string,mixed> $payload Deployment body.
	 * @return array<string,mixed>|WP_Error
	 */
	public static function deploy_article( array $payload ) {
		$deployment_id = isset( $payload['deployment_id'] ) ? (string) $payload['deployment_id'] : '';
		$force         = ! empty( $payload['force'] );
		$article       = isset( $payload['article'] ) && is_array( $payload['article'] ) ? $payload['article'] : $payload;
		$apply_mode    = isset( $article['apply_mode'] ) ? (string) $article['apply_mode'] : '';

		if ( '' === $apply_mode ) {
			$apply_mode = function_exists( 'hap_esm_adapter_hap_studio_apply' ) ? 'hap_studio' : 'html_sections';
		}

		if ( 'hap_studio' === $apply_mode ) {
			return self::deploy_hap_studio( $article, $deployment_id, $force );
		}

		$validation = self::validate_generic( $article, $apply_mode );
		if ( is_wp_error( $validation ) ) {
			return $validation;
		}

		return self::apply_generic( $article, $deployment_id, $force, $apply_mode );
	}

	/**
	 * Validate without apply.
	 *
	 * @param array<string,mixed> $article Article.
	 * @return array{ok:bool,errors:array,warnings:array,apply_mode:string}|WP_Error
	 */
	public static function validate_article( array $article ) {
		$apply_mode = isset( $article['apply_mode'] ) ? (string) $article['apply_mode'] : '';
		if ( '' === $apply_mode ) {
			$apply_mode = function_exists( 'hap_esm_studio_validate' ) ? 'hap_studio' : 'html_sections';
		}

		if ( 'hap_studio' === $apply_mode ) {
			if ( ! function_exists( 'hap_esm_studio_validate' ) ) {
				return new WP_Error( 'hap_bridge_esm_missing', 'Hap Scale Publish not active.', array( 'status' => 503 ) );
			}
			$validation = hap_esm_studio_validate( $article );
			return array(
				'ok'         => ! empty( $validation['ok'] ),
				'errors'     => $validation['errors'] ?? array(),
				'warnings'   => $validation['warnings'] ?? array(),
				'apply_mode' => 'hap_studio',
			);
		}

		$v = self::validate_generic( $article, $apply_mode );
		if ( is_wp_error( $v ) ) {
			$data = $v->get_error_data();
			return array(
				'ok'         => false,
				'errors'     => is_array( $data['errors'] ?? null ) ? $data['errors'] : array( $v->get_error_message() ),
				'warnings'   => array(),
				'apply_mode' => $apply_mode,
			);
		}
		return array(
			'ok'         => true,
			'errors'     => array(),
			'warnings'   => array(),
			'apply_mode' => $apply_mode,
		);
	}

	/**
	 * @param array<string,mixed> $article Article.
	 * @param string              $deployment_id Deployment id.
	 * @param bool                $force Force.
	 * @return array<string,mixed>|WP_Error
	 */
	private static function deploy_hap_studio( array $article, $deployment_id, $force ) {
		if ( ! function_exists( 'hap_esm_studio_validate' ) || ! function_exists( 'hap_esm_adapter_hap_studio_apply' ) ) {
			return new WP_Error( 'hap_bridge_esm_missing', 'Hap Scale Publish not active.', array( 'status' => 503 ) );
		}

		$validation = hap_esm_studio_validate( $article );
		if ( empty( $validation['ok'] ) ) {
			return new WP_Error(
				'hap_bridge_validation_failed',
				'Validation failed.',
				array(
					'status'   => 422,
					'errors'   => $validation['errors'],
					'warnings' => $validation['warnings'],
				)
			);
		}

		$doc = $validation['doc'];
		$conflict = self::check_conflict( $doc, $force );
		if ( is_wp_error( $conflict ) ) {
			return $conflict;
		}

		$result = hap_esm_adapter_hap_studio_apply( $doc );
		if ( empty( $result['ok'] ) ) {
			return new WP_Error(
				'hap_bridge_apply_failed',
				implode( ' ', $result['errors'] ?? array( 'Apply failed.' ) ),
				array( 'status' => 500 )
			);
		}

		$post_id = (int) $result['post_id'];
		$hash    = self::content_hash_for_post( $post_id, $doc );

		update_post_meta( $post_id, '_hap_crm_deployment_id', $deployment_id );
		update_post_meta( $post_id, '_hap_crm_content_hash', $hash );
		update_post_meta( $post_id, '_hap_crm_last_deploy_at', gmdate( 'c' ) );

		$ack = array(
			'schema_version' => 1,
			'deployment_id'  => $deployment_id,
			'post_id'        => $post_id,
			'status'         => $result['status'] ?? 'draft',
			'permalink'      => $result['permalink'] ?? '',
			'edit_url'       => $result['edit_url'] ?? '',
			'content_hash'   => $hash,
			'warnings'       => $validation['warnings'] ?? array(),
			'message'        => $result['message'] ?? '',
			'apply_mode'     => 'hap_studio',
		);

		if ( function_exists( 'hap_esm_build_checklist' ) ) {
			$ack['checks'] = hap_esm_build_checklist( $post_id, false, false );
		}

		return $ack;
	}

	/**
	 * MVP generic apply: title/slug/content_html + SEO meta + flat meta map.
	 * Refuses Gutenberg block blueprints.
	 *
	 * @param array<string,mixed> $article Article.
	 * @param string              $apply_mode Mode.
	 * @return true|WP_Error
	 */
	private static function validate_generic( array $article, $apply_mode ) {
		$errors = array();
		if ( empty( $article['title'] ) || strlen( (string) $article['title'] ) < 3 ) {
			$errors[] = 'title required (min 3).';
		}
		if ( empty( $article['slug'] ) || ! preg_match( '/^[a-z0-9]+(?:-[a-z0-9]+)*$/', (string) $article['slug'] ) ) {
			$errors[] = 'slug required (lowercase kebab).';
		}
		if ( ! empty( $article['has_blocks'] ) || 'block_blueprint' === $apply_mode ) {
			$errors[] = 'Gutenberg/ACF block blueprints are not supported in Bridge MVP apply_mode.';
		}
		$html = (string) ( $article['content_html'] ?? '' );
		$sections = $article['sections'] ?? null;
		if ( '' === trim( $html ) && empty( $sections ) ) {
			$errors[] = 'content_html or sections required.';
		}
		if ( $errors ) {
			return new WP_Error(
				'hap_bridge_validation_failed',
				'Validation failed.',
				array(
					'status' => 422,
					'errors' => $errors,
				)
			);
		}
		return true;
	}

	/**
	 * @param array<string,mixed> $article Article.
	 * @param string              $deployment_id ID.
	 * @param bool                $force Force.
	 * @param string              $apply_mode Mode.
	 * @return array<string,mixed>|WP_Error
	 */
	private static function apply_generic( array $article, $deployment_id, $force, $apply_mode ) {
		$post_type = isset( $article['type'] ) ? sanitize_key( (string) $article['type'] ) : 'post';
		if ( ! post_type_exists( $post_type ) ) {
			$post_type = 'post';
		}

		$content = (string) ( $article['content_html'] ?? '' );
		if ( '' === trim( $content ) && ! empty( $article['sections'] ) && is_array( $article['sections'] ) ) {
			$content = self::sections_to_html( $article['sections'] );
		}

		$slug = sanitize_title( (string) $article['slug'] );
		$existing = get_page_by_path( $slug, OBJECT, $post_type );
		$post_id  = $existing ? (int) $existing->ID : 0;

		if ( $post_id > 0 ) {
			$conflict = self::check_conflict(
				array(
					'id'   => $post_id,
					'slug' => $slug,
				),
				$force
			);
			if ( is_wp_error( $conflict ) ) {
				return $conflict;
			}
		}

		$postarr = array(
			'post_title'   => sanitize_text_field( (string) $article['title'] ),
			'post_name'    => $slug,
			'post_content' => $content,
			'post_status'  => 'draft',
			'post_type'    => $post_type,
		);
		if ( $post_id > 0 ) {
			$postarr['ID'] = $post_id;
			$new_id        = wp_update_post( $postarr, true );
		} else {
			$new_id = wp_insert_post( $postarr, true );
		}
		if ( is_wp_error( $new_id ) ) {
			return $new_id;
		}
		$post_id = (int) $new_id;

		if ( ! empty( $article['featured_media_id'] ) ) {
			set_post_thumbnail( $post_id, (int) $article['featured_media_id'] );
		}

		$seo = is_array( $article['seo'] ?? null ) ? $article['seo'] : array();
		if ( $seo ) {
			if ( isset( $seo['title'] ) ) {
				update_post_meta( $post_id, '_yoast_wpseo_title', sanitize_text_field( (string) $seo['title'] ) );
				update_post_meta( $post_id, 'rank_math_title', sanitize_text_field( (string) $seo['title'] ) );
			}
			if ( isset( $seo['description'] ) ) {
				update_post_meta( $post_id, '_yoast_wpseo_metadesc', sanitize_text_field( (string) $seo['description'] ) );
				update_post_meta( $post_id, 'rank_math_description', sanitize_text_field( (string) $seo['description'] ) );
			}
			if ( isset( $seo['focus_keyword'] ) ) {
				update_post_meta( $post_id, '_yoast_wpseo_focuskw', sanitize_text_field( (string) $seo['focus_keyword'] ) );
				update_post_meta( $post_id, 'rank_math_focus_keyword', sanitize_text_field( (string) $seo['focus_keyword'] ) );
			}
		}

		if ( 'meta_map' === $apply_mode && ! empty( $article['meta'] ) && is_array( $article['meta'] ) ) {
			foreach ( $article['meta'] as $key => $value ) {
				$key = (string) $key;
				if ( '' === $key || str_starts_with( $key, '_hap_crm' ) ) {
					continue;
				}
				if ( is_scalar( $value ) || null === $value ) {
					update_post_meta( $post_id, $key, $value );
				}
			}
		}

		$hash = self::content_hash_for_post( $post_id, $article );
		update_post_meta( $post_id, '_hap_crm_deployment_id', $deployment_id );
		update_post_meta( $post_id, '_hap_crm_content_hash', $hash );
		update_post_meta( $post_id, '_hap_crm_last_deploy_at', gmdate( 'c' ) );

		return array(
			'schema_version' => 1,
			'deployment_id'  => $deployment_id,
			'post_id'        => $post_id,
			'status'         => 'draft',
			'permalink'      => get_permalink( $post_id ),
			'edit_url'       => get_edit_post_link( $post_id, 'raw' ),
			'content_hash'   => $hash,
			'warnings'       => array(),
			'message'        => 'Draft created via generic apply_mode.',
			'apply_mode'     => $apply_mode,
		);
	}

	/**
	 * @param array<int, array<string,mixed>> $sections Sections.
	 */
	private static function sections_to_html( array $sections ) {
		$html = '';
		foreach ( $sections as $sec ) {
			if ( ! is_array( $sec ) ) {
				continue;
			}
			$h = (string) ( $sec['heading'] ?? $sec['h2'] ?? '' );
			$a = sanitize_title( (string) ( $sec['anchor'] ?? $h ) );
			if ( $h ) {
				$html .= '<h2 id="' . esc_attr( $a ) . '">' . esc_html( $h ) . '</h2>';
			}
			foreach ( (array) ( $sec['paragraphs'] ?? array() ) as $p ) {
				$p = trim( (string) $p );
				if ( $p ) {
					$html .= '<p>' . esc_html( $p ) . '</p>';
				}
			}
		}
		return $html;
	}

	/**
	 * @param array<string,mixed> $doc Validated article.
	 * @param bool                $force Force overwrite.
	 * @return true|WP_Error
	 */
	private static function check_conflict( array $doc, $force ) {
		if ( $force ) {
			return true;
		}
		$post_id = isset( $doc['id'] ) ? (int) $doc['id'] : 0;
		$slug    = isset( $doc['slug'] ) ? (string) $doc['slug'] : '';
		$type    = isset( $doc['type'] ) ? (string) $doc['type'] : 'post';
		if ( $post_id <= 0 && '' !== $slug ) {
			$existing = get_page_by_path( $slug, OBJECT, $type );
			if ( $existing ) {
				$post_id = (int) $existing->ID;
			}
		}
		if ( $post_id <= 0 ) {
			return true;
		}

		$stored = (string) get_post_meta( $post_id, '_hap_crm_content_hash', true );
		if ( '' === $stored ) {
			return true;
		}

		$current = self::content_hash_for_post( $post_id, $doc );
		if ( hash_equals( $stored, $current ) ) {
			return true;
		}

		return new WP_Error(
			'hap_bridge_conflict',
			'Content changed on WordPress since last CRM deploy.',
			array(
				'status'             => 409,
				'post_id'            => $post_id,
				'last_deployed_hash' => $stored,
				'current_wp_hash'    => $current,
				'edit_url'           => get_edit_post_link( $post_id, 'raw' ),
			)
		);
	}

	/**
	 * @param int                 $post_id Post ID (0 if new).
	 * @param array<string,mixed> $doc Article doc.
	 * @return string SHA256 hex.
	 */
	public static function content_hash_for_post( $post_id, array $doc ) {
		if ( $post_id > 0 ) {
			$post = get_post( $post_id );
			if ( $post ) {
				$blob = $post->post_title . "\n" . $post->post_content . "\n" . $post->post_name;
				return hash( 'sha256', $blob );
			}
		}
		$blob = wp_json_encode( $doc );
		return hash( 'sha256', (string) $blob );
	}
}
