<?php
/**
 * Collect site health payload slots expected by CRM fn-website-update.php.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Hap_Bridge_Collector {

	/**
	 * Build 29 encrypted slots for CRM import.
	 *
	 * @return array<int,array<int,string>>
	 */
	public function build_encrypted_slots() {
		$plain = $this->build_plain_slots();
		$out   = array();
		foreach ( $plain as $slot ) {
			$out[] = Hap_Bridge_Crypto::encrypt_list( $slot );
		}
		return $out;
	}

	/**
	 * @return array<int,array<int,string>>
	 */
	public function build_plain_slots() {
		$errors = $this->collect_errors();

		$slots   = array();
		$slots[] = array_values( $errors['notice'] ); // 0 values
		$slots[] = array_keys( $errors['notice'] );   // 1 keys
		$slots[] = array_values( $errors['warning'] );
		$slots[] = array_keys( $errors['warning'] );
		$slots[] = array_values( $errors['error'] );
		$slots[] = array_keys( $errors['error'] );
		$slots[] = array_values( $errors['fatal'] );
		$slots[] = array_keys( $errors['fatal'] );

		$slots[] = $this->collect_versions(); // 8
		$plugins = $this->collect_plugins();
		$slots[] = $plugins['installed']; // 9
		$slots[] = $plugins['active']; // 10
		$slots[] = $plugins['inactive']; // 11
		$slots[] = $plugins['to_be_updated']; // 12

		$themes = $this->collect_themes();
		$slots[] = $themes['installed']; // 13
		$slots[] = $themes['theme_active']; // 14
		$slots[] = $themes['theme_parent']; // 15
		$slots[] = $themes['to_be_updated']; // 16

		$slots[] = $this->collect_users(); // 17
		$slots[] = $this->collect_host(); // 18
		$slots[] = $this->collect_languages(); // 19
		$slots[] = $this->collect_post_types( true ); // 20 public
		$slots[] = $this->collect_post_types( false ); // 21 private
		$slots[] = $this->collect_attachments(); // 22
		$slots[] = $this->collect_acf_post_types(); // 23
		$slots[] = $this->collect_roles(); // 24
		$slots[] = $this->collect_taxonomies( true ); // 25
		$slots[] = $this->collect_taxonomies( false ); // 26
		$slots[] = $this->collect_comments(); // 27
		$slots[] = $this->collect_last_logins(); // 28

		return $slots;
	}

	/**
	 * Remote health flags merged into CRM errors meta.
	 * Always emit freshness keys so stale OTR-101/202/300 cannot linger.
	 *
	 * @return array{notice:array<string,int|string>,warning:array<string,int|string>,error:array<string,int|string>,fatal:array<string,int|string>}
	 */
	private function collect_errors() {
		$notice  = array(
			'VRS-204' => 0,
			'OTR-101' => 0,
			'DBL-100' => 0,
		);
		$warning = array(
			'OTR-202' => 0,
			'DBL-200' => 0,
		);
		$error   = array(
			'OTR-300' => 0,
		);
		$fatal   = array();

		// Signal outdated WP core as soft notice for CRM merge.
		$updates = get_site_transient( 'update_core' );
		if ( is_object( $updates ) && ! empty( $updates->updates ) ) {
			foreach ( $updates->updates as $update ) {
				if ( isset( $update->response ) && 'upgrade' === $update->response ) {
					$notice['VRS-100'] = 1;
					break;
				}
			}
		}

		$freshness = $this->collect_content_freshness();
		$notice['OTR-101']  = $freshness['OTR-101'];
		$warning['OTR-202'] = $freshness['OTR-202'];
		$error['OTR-300']   = $freshness['OTR-300'];

		$debug = $this->collect_debug_log_flags();
		$notice['DBL-100']  = $debug['DBL-100'];
		$warning['DBL-200'] = $debug['DBL-200'];

		return array(
			'notice'  => $notice,
			'warning' => $warning,
			'error'   => $error,
			'fatal'   => $fatal,
		);
	}

	/**
	 * DBL-100/200 from WP_DEBUG + debug.log (always emitted to overwrite stale CRM meta).
	 *
	 * @return array{DBL-100:int,DBL-200:int|string}
	 */
	private function collect_debug_log_flags() {
		$out = array(
			'DBL-100' => 0,
			'DBL-200' => 0,
		);

		$log_path = WP_CONTENT_DIR . '/debug.log';
		$has_log  = is_readable( $log_path ) && filesize( $log_path ) > 0;
		$debug_on = ( defined( 'WP_DEBUG' ) && WP_DEBUG )
			|| ( defined( 'WP_DEBUG_LOG' ) && WP_DEBUG_LOG );

		if ( $debug_on && $has_log ) {
			$out['DBL-100'] = 1;
		}

		if ( $has_log ) {
			$mtime = filemtime( $log_path );
			if ( $mtime ) {
				// Same format historically shown in CRM (d/m/Y H:i:s).
				$out['DBL-200'] = gmdate( 'd/m/Y H:i:s', $mtime + (int) ( get_option( 'gmt_offset' ) * HOUR_IN_SECONDS ) );
			}
		}

		return $out;
	}

	/**
	 * Last public content activity → OTR-101 (months 1–6), OTR-202 (months 7–11), OTR-300 (years ≥ 1).
	 *
	 * @return array{OTR-101:int,OTR-202:int,OTR-300:int}
	 */
	private function collect_content_freshness() {
		$out = array(
			'OTR-101' => 0,
			'OTR-202' => 0,
			'OTR-300' => 0,
		);

		$types = get_post_types(
			array(
				'public' => true,
			),
			'names'
		);
		unset( $types['attachment'] );
		if ( ! $types ) {
			return $out;
		}

		$latest = get_posts(
			array(
				'post_type'              => array_values( $types ),
				'post_status'            => 'publish',
				'numberposts'            => 1,
				'orderby'                => 'modified',
				'order'                  => 'DESC',
				'fields'                 => 'ids',
				'no_found_rows'          => true,
				'update_post_meta_cache' => false,
				'update_post_term_cache' => false,
			)
		);
		if ( ! $latest ) {
			return $out;
		}

		$modified = get_post_field( 'post_modified_gmt', (int) $latest[0] );
		if ( ! $modified ) {
			return $out;
		}

		try {
			$then  = new DateTimeImmutable( $modified, new DateTimeZone( 'UTC' ) );
			$now   = new DateTimeImmutable( 'now', new DateTimeZone( 'UTC' ) );
			$diff  = $now->diff( $then );
			$years = (int) $diff->y;
			$months_total = ( $years * 12 ) + (int) $diff->m;
		} catch ( Exception $e ) {
			return $out;
		}

		if ( $years >= 1 ) {
			$out['OTR-300'] = max( 1, $years );
		} elseif ( $months_total > 6 ) {
			$out['OTR-202'] = $months_total;
		} elseif ( $months_total >= 1 ) {
			$out['OTR-101'] = $months_total;
		}

		return $out;
	}

	/**
	 * @return array<int,string>
	 */
	private function collect_versions() {
		global $wpdb, $wp_version;

		$acf = defined( 'ACF_VERSION' ) ? ACF_VERSION : '';
		$sql = '';
		if ( isset( $wpdb ) && method_exists( $wpdb, 'db_server_info' ) ) {
			$sql = (string) $wpdb->db_server_info();
		} elseif ( isset( $wpdb ) && method_exists( $wpdb, 'db_version' ) ) {
			$sql = (string) $wpdb->db_version();
		}

		$jquery = $GLOBALS['wp_scripts']->registered['jquery']->ver ?? '';
		if ( is_string( $jquery ) && str_contains( $jquery, '-' ) ) {
			$jquery = explode( '-', $jquery )[0];
		}

		return array(
			(string) $wp_version,
			$sql,
			PHP_VERSION,
			(string) $acf,
			(string) $jquery,
		);
	}

	/**
	 * @return array{installed:string[],active:string[],inactive:string[],to_be_updated:string[]}
	 */
	private function collect_plugins() {
		if ( ! function_exists( 'get_plugins' ) ) {
			require_once ABSPATH . 'wp-admin/includes/plugin.php';
		}
		$all      = get_plugins();
		$active   = get_option( 'active_plugins', array() );
		$network  = is_multisite() ? array_keys( (array) get_site_option( 'active_sitewide_plugins', array() ) ) : array();
		$active   = array_unique( array_merge( (array) $active, $network ) );

		$installed = array();
		$active_n  = array();
		$inactive  = array();
		foreach ( $all as $file => $data ) {
			$name = isset( $data['Name'] ) ? (string) $data['Name'] : $file;
			$installed[] = $name;
			if ( in_array( $file, $active, true ) ) {
				$active_n[] = $name;
			} else {
				$inactive[] = $name;
			}
		}

		$to_update = array();
		$upd       = get_site_transient( 'update_plugins' );
		if ( is_object( $upd ) && ! empty( $upd->response ) && is_array( $upd->response ) ) {
			foreach ( $upd->response as $file => $info ) {
				if ( isset( $all[ $file ]['Name'] ) ) {
					$to_update[] = (string) $all[ $file ]['Name'];
				}
			}
		}

		return array(
			'installed'     => $installed,
			'active'        => $active_n,
			'inactive'      => $inactive,
			'to_be_updated' => $to_update,
		);
	}

	/**
	 * @return array{installed:string[],theme_active:string[],theme_parent:string[],to_be_updated:string[]}
	 */
	private function collect_themes() {
		$themes    = wp_get_themes();
		$installed = array();
		foreach ( $themes as $theme ) {
			$installed[] = $theme->get( 'Name' );
		}

		$current = wp_get_theme();
		$active  = array(
			(string) $current->get( 'Name' ),
			(string) $current->get( 'ThemeURI' ),
			(string) $current->get( 'Description' ),
			(string) $current->get( 'Author' ),
			(string) $current->get( 'Version' ),
			(string) $current->get( 'TextDomain' ),
			(string) $current->get( 'RequiresWP' ),
			(string) $current->get( 'RequiresPHP' ),
			(string) $current->get_template(),
		);

		$parent_vals = array();
		$parent      = $current->parent();
		if ( $parent ) {
			$parent_vals = array(
				(string) $parent->get( 'Name' ),
				(string) $parent->get( 'ThemeURI' ),
				(string) $parent->get( 'Description' ),
				(string) $parent->get( 'Author' ),
				(string) $parent->get( 'Version' ),
				(string) $parent->get( 'TextDomain' ),
				(string) $parent->get( 'RequiresWP' ),
				(string) $parent->get( 'RequiresPHP' ),
			);
		}

		$to_update = array();
		$upd       = get_site_transient( 'update_themes' );
		if ( is_object( $upd ) && ! empty( $upd->response ) && is_array( $upd->response ) ) {
			foreach ( $upd->response as $stylesheet => $info ) {
				$t = wp_get_theme( $stylesheet );
				if ( $t->exists() ) {
					$to_update[] = $t->get( 'Name' );
				}
			}
		}

		return array(
			'installed'     => $installed,
			'theme_active'  => $active,
			'theme_parent'  => $parent_vals,
			'to_be_updated' => $to_update,
		);
	}

	/**
	 * @return array<int,string>
	 */
	private function collect_users() {
		$counts = count_users();
		$avail  = isset( $counts['avail_roles'] ) ? $counts['avail_roles'] : array();
		$admin  = (int) ( $avail['administrator'] ?? 0 );
		$editor = (int) ( $avail['editor'] ?? 0 );
		$total  = (int) ( $counts['total_users'] ?? 0 );
		$other  = max( 0, $total - $admin - $editor );

		$hap = 0;
		$users = get_users( array( 'fields' => array( 'ID', 'user_email' ), 'number' => 500 ) );
		foreach ( $users as $u ) {
			if ( str_contains( strtolower( (string) $u->user_email ), 'hap-studio' ) ) {
				$hap++;
			}
		}

		return array( (string) $admin, (string) $editor, (string) $other, (string) $hap );
	}

	/**
	 * @return array<int,string>
	 */
	private function collect_host() {
		$host = isset( $_SERVER['HTTP_HOST'] ) ? (string) $_SERVER['HTTP_HOST'] : (string) wp_parse_url( home_url(), PHP_URL_HOST );
		$soft = isset( $_SERVER['SERVER_SOFTWARE'] ) ? (string) $_SERVER['SERVER_SOFTWARE'] : '';
		$server = 'Apache';
		if ( stripos( $soft, 'nginx' ) !== false ) {
			$server = 'Nginx';
		} elseif ( stripos( $soft, 'litespeed' ) !== false ) {
			$server = 'LiteSpeed';
		}
		$ip = isset( $_SERVER['SERVER_ADDR'] ) ? (string) $_SERVER['SERVER_ADDR'] : '';
		return array( $host, $server, $ip );
	}

	/**
	 * @return array<int,string>
	 */
	private function collect_languages() {
		$locale = get_locale();
		$list   = array( $locale );
		if ( function_exists( 'get_available_languages' ) ) {
			foreach ( get_available_languages() as $lang ) {
				if ( ! in_array( $lang, $list, true ) ) {
					$list[] = $lang;
				}
			}
		}
		return $list;
	}

	/**
	 * @param bool $public Public post types.
	 * @return array<int,string> slug:count
	 */
	private function collect_post_types( $public ) {
		$types = get_post_types( array( 'public' => (bool) $public ), 'names' );
		$out   = array();
		foreach ( $types as $type ) {
			$counts = wp_count_posts( $type );
			$n      = 0;
			if ( is_object( $counts ) ) {
				foreach ( get_object_vars( $counts ) as $v ) {
					$n += (int) $v;
				}
			}
			$out[] = $type . ':' . $n;
		}
		return $out;
	}

	/**
	 * @return array<int,string>
	 */
	private function collect_attachments() {
		$counts = wp_count_posts( 'attachment' );
		$n      = is_object( $counts ) ? (int) ( $counts->inherit ?? 0 ) + (int) ( $counts->private ?? 0 ) : 0;
		return array( 'attachment:' . $n );
	}

	/**
	 * @return array<int,string>
	 */
	private function collect_acf_post_types() {
		if ( ! function_exists( 'acf_get_post_types' ) ) {
			return array();
		}
		$types = acf_get_post_types();
		$out   = array();
		if ( is_array( $types ) ) {
			foreach ( $types as $type ) {
				$out[] = $type . ':0';
			}
		}
		return $out;
	}

	/**
	 * @return array<int,string>
	 */
	private function collect_roles() {
		$roles = wp_roles();
		return array_keys( $roles->roles );
	}

	/**
	 * @param bool $public Public taxonomies.
	 * @return array<int,string>
	 */
	private function collect_taxonomies( $public ) {
		$taxes = get_taxonomies( array( 'public' => (bool) $public ), 'names' );
		$out   = array();
		foreach ( $taxes as $tax ) {
			$terms = wp_count_terms( array( 'taxonomy' => $tax, 'hide_empty' => false ) );
			$n     = is_wp_error( $terms ) ? 0 : (int) $terms;
			$out[] = $tax . ':' . $n;
		}
		return $out;
	}

	/**
	 * @return array<int,string>
	 */
	private function collect_comments() {
		$c = wp_count_comments();
		return array(
			(string) ( $c->approved ?? 0 ),
			(string) ( $c->spam ?? 0 ),
			(string) ( $c->trash ?? 0 ),
			(string) ( $c->{'post-trashed'} ?? 0 ),
			(string) ( $c->all ?? 0 ),
			(string) ( $c->total_comments ?? 0 ),
			(string) ( $c->moderated ?? 0 ),
		);
	}

	/**
	 * Last login timestamps if meta exists; otherwise empty placeholders.
	 *
	 * @return array<int,string>
	 */
	private function collect_last_logins() {
		$pick = function ( $role ) {
			$users = get_users(
				array(
					'role'   => $role,
					'number' => 1,
					'orderby' => 'meta_value',
					'meta_key' => 'last_login',
					'order'  => 'DESC',
				)
			);
			if ( ! $users ) {
				return '';
			}
			$v = get_user_meta( $users[0]->ID, 'last_login', true );
			return $v ? (string) $v : '';
		};

		$hap = '';
		$users = get_users( array( 'number' => 20, 'orderby' => 'ID', 'order' => 'DESC' ) );
		foreach ( $users as $u ) {
			if ( str_contains( strtolower( $u->user_email ), 'hap-studio' ) ) {
				$hap = (string) get_user_meta( $u->ID, 'last_login', true );
				break;
			}
		}

		return array(
			$hap,
			$pick( 'administrator' ),
			$pick( 'editor' ),
			'',
			'',
		);
	}
}
