<?php
/**
 * Admin settings UI — save / clear API key and unpair analysis without wp-config.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Hap_Bridge_Admin {

	const OPTION_API_KEY   = 'hap_site_bridge_api_key';
	const OPTION_WRITE_KEY = 'hap_site_bridge_write_key';
	const PAGE_SLUG        = 'hap-site-bridge';

	public static function init() {
		add_action( 'admin_menu', array( __CLASS__, 'register_menu' ) );
		add_filter( 'plugin_action_links_' . plugin_basename( HAP_SITE_BRIDGE_FILE ), array( __CLASS__, 'action_links' ) );
	}

	/**
	 * @param array<int,string> $links Links.
	 * @return array<int,string>
	 */
	public static function action_links( $links ) {
		$url = admin_url( 'options-general.php?page=' . self::PAGE_SLUG );
		array_unshift(
			$links,
			'<a href="' . esc_url( $url ) . '">' . esc_html__( 'Settings', 'hap-site-bridge' ) . '</a>'
		);
		return $links;
	}

	public static function register_menu() {
		add_options_page(
			__( 'Hap Site Bridge', 'hap-site-bridge' ),
			__( 'Hap Bridge', 'hap-site-bridge' ),
			'manage_options',
			self::PAGE_SLUG,
			array( __CLASS__, 'render_page' )
		);
	}

	public static function render_page() {
		if ( ! current_user_can( 'manage_options' ) ) {
			return;
		}

		$notice = '';
		if (
			isset( $_POST['hap_bridge_settings_nonce'] )
			&& wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['hap_bridge_settings_nonce'] ) ), 'hap_bridge_save_settings' )
		) {
			$notice = self::save_posted();
		}

		$api_locked   = defined( 'HAP_SITE_BRIDGE_API_KEY' ) && HAP_SITE_BRIDGE_API_KEY;
		$write_locked = defined( 'HAP_SITE_BRIDGE_WRITE_KEY' ) && HAP_SITE_BRIDGE_WRITE_KEY;
		$api_set      = hap_site_bridge_api_key() !== '';
		$write_set    = hap_site_bridge_write_key() !== '';
		$v2_paired    = Hap_Bridge_Connection::is_paired();
		?>
		<div class="wrap">
			<h1><?php esc_html_e( 'Hap Site Bridge', 'hap-site-bridge' ); ?></h1>
			<p><?php esc_html_e( 'Paste the same read API key stored in HAP OS (Sites → Hap Bridge → Credentials). No wp-config edit required.', 'hap-site-bridge' ); ?></p>

			<?php if ( $notice ) : ?>
				<div class="notice notice-success is-dismissible"><p><?php echo esc_html( $notice ); ?></p></div>
			<?php endif; ?>

			<form method="post">
				<?php wp_nonce_field( 'hap_bridge_save_settings', 'hap_bridge_settings_nonce' ); ?>
				<table class="form-table" role="presentation">
					<tr>
						<th scope="row">
							<label for="hap_site_bridge_api_key"><?php esc_html_e( 'Read API key', 'hap-site-bridge' ); ?></label>
						</th>
						<td>
							<?php if ( $api_locked ) : ?>
								<input type="text" class="regular-text" value="<?php esc_attr_e( 'Set in wp-config (HAP_SITE_BRIDGE_API_KEY)', 'hap-site-bridge' ); ?>" disabled />
								<p class="description"><?php esc_html_e( 'Constant overrides the field. Remove HAP_SITE_BRIDGE_API_KEY from wp-config to clear/unpair from this screen.', 'hap-site-bridge' ); ?></p>
							<?php else : ?>
								<input
									type="password"
									class="regular-text"
									id="hap_site_bridge_api_key"
									name="hap_site_bridge_api_key"
									value=""
									autocomplete="new-password"
									placeholder="<?php echo $api_set ? esc_attr__( '•••• saved — paste to replace', 'hap-site-bridge' ) : esc_attr__( 'Paste API key from HAP OS', 'hap-site-bridge' ); ?>"
								/>
								<p class="description">
									<?php
									echo $api_set
										? esc_html__( 'A key is already saved. Leave blank to keep it, or paste a new one to replace.', 'hap-site-bridge' )
										: esc_html__( 'Required for HAP OS site analysis (GET hap/v1/data).', 'hap-site-bridge' );
									?>
								</p>
								<?php if ( $api_set ) : ?>
									<p>
										<label>
											<input type="checkbox" name="hap_bridge_clear_api_key" value="1" />
											<?php esc_html_e( 'Clear read API key (unpair analysis channel)', 'hap-site-bridge' ); ?>
										</label>
									</p>
								<?php endif; ?>
							<?php endif; ?>
						</td>
					</tr>
					<tr>
						<th scope="row">
							<label for="hap_site_bridge_write_key"><?php esc_html_e( 'Write key (optional)', 'hap-site-bridge' ); ?></label>
						</th>
						<td>
							<?php if ( $write_locked ) : ?>
								<input type="text" class="regular-text" value="<?php esc_attr_e( 'Set in wp-config (HAP_SITE_BRIDGE_WRITE_KEY)', 'hap-site-bridge' ); ?>" disabled />
							<?php else : ?>
								<input
									type="password"
									class="regular-text"
									id="hap_site_bridge_write_key"
									name="hap_site_bridge_write_key"
									value=""
									autocomplete="new-password"
									placeholder="<?php echo $write_set ? esc_attr__( '•••• saved — paste to replace', 'hap-site-bridge' ) : esc_attr__( 'Optional', 'hap-site-bridge' ); ?>"
								/>
								<p class="description"><?php esc_html_e( 'Only for legacy draft write. Leave empty if unused.', 'hap-site-bridge' ); ?></p>
								<?php if ( $write_set ) : ?>
									<p>
										<label>
											<input type="checkbox" name="hap_bridge_clear_write_key" value="1" />
											<?php esc_html_e( 'Clear write key', 'hap-site-bridge' ); ?>
										</label>
									</p>
								<?php endif; ?>
							<?php endif; ?>
						</td>
					</tr>
					<tr>
						<th scope="row"><?php esc_html_e( 'Status', 'hap-site-bridge' ); ?></th>
						<td>
							<p>
								<strong><?php esc_html_e( 'Version', 'hap-site-bridge' ); ?>:</strong>
								<?php echo esc_html( HAP_SITE_BRIDGE_VERSION ); ?>
							</p>
							<p>
								<strong><?php esc_html_e( 'Analysis (read API key)', 'hap-site-bridge' ); ?>:</strong>
								<?php echo $api_set ? esc_html__( 'configured', 'hap-site-bridge' ) : esc_html__( 'missing — HAP OS will show Unpaired', 'hap-site-bridge' ); ?>
							</p>
							<p>
								<strong><?php esc_html_e( 'v2 connection', 'hap-site-bridge' ); ?>:</strong>
								<?php echo $v2_paired ? esc_html__( 'paired', 'hap-site-bridge' ) : esc_html__( 'not paired', 'hap-site-bridge' ); ?>
							</p>
						</td>
					</tr>
				</table>
				<?php submit_button( __( 'Save settings', 'hap-site-bridge' ) ); ?>
			</form>

			<?php if ( $api_set && ! $api_locked ) : ?>
				<hr />
				<form method="post" onsubmit="return confirm('<?php echo esc_js( __( 'Clear the read API key? HAP OS will see Unpaired and stop reading site analysis.', 'hap-site-bridge' ) ); ?>');">
					<?php wp_nonce_field( 'hap_bridge_save_settings', 'hap_bridge_settings_nonce' ); ?>
					<input type="hidden" name="hap_bridge_clear_api_key" value="1" />
					<input type="hidden" name="hap_bridge_action" value="unpair_analysis" />
					<?php submit_button( __( 'Unpair analysis (clear read API key)', 'hap-site-bridge' ), 'delete', 'submit', false ); ?>
					<p class="description"><?php esc_html_e( 'Use this to test HAP OS unpaired state. Then open Sites → Connector and run Pairing Bridge.', 'hap-site-bridge' ); ?></p>
				</form>
			<?php endif; ?>
		</div>
		<?php
	}

	/**
	 * @return string Notice text.
	 */
	private static function save_posted() {
		if ( ! current_user_can( 'manage_options' ) ) {
			return '';
		}

		$cleared_api = false;

		if ( ! ( defined( 'HAP_SITE_BRIDGE_API_KEY' ) && HAP_SITE_BRIDGE_API_KEY ) ) {
			$clear_api = ! empty( $_POST['hap_bridge_clear_api_key'] )
				|| ( isset( $_POST['hap_bridge_action'] ) && 'unpair_analysis' === $_POST['hap_bridge_action'] );
			if ( $clear_api ) {
				delete_option( self::OPTION_API_KEY );
				$cleared_api = true;
			} else {
				$api = isset( $_POST['hap_site_bridge_api_key'] ) ? trim( (string) wp_unslash( $_POST['hap_site_bridge_api_key'] ) ) : '';
				if ( $api !== '' ) {
					update_option( self::OPTION_API_KEY, $api, false );
				}
			}
		}

		if ( ! ( defined( 'HAP_SITE_BRIDGE_WRITE_KEY' ) && HAP_SITE_BRIDGE_WRITE_KEY ) ) {
			if ( ! empty( $_POST['hap_bridge_clear_write_key'] ) ) {
				delete_option( self::OPTION_WRITE_KEY );
			} else {
				$write = isset( $_POST['hap_site_bridge_write_key'] ) ? trim( (string) wp_unslash( $_POST['hap_site_bridge_write_key'] ) ) : '';
				if ( $write !== '' ) {
					update_option( self::OPTION_WRITE_KEY, $write, false );
				}
			}
		}

		if ( $cleared_api ) {
			return __( 'Read API key cleared. Analysis channel unpaired — HAP OS will report Unpaired after the next Bridge verify.', 'hap-site-bridge' );
		}
		return __( 'Settings saved.', 'hap-site-bridge' );
	}
}
