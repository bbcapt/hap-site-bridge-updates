<?php
/**
 * Private update channel + auto-updates for Hap-managed sites.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Metadata JSON URL (override in wp-config if needed).
 *
 * @return string
 */
function hap_site_bridge_update_json_url() {
	if ( defined( 'HAP_SITE_BRIDGE_UPDATE_JSON' ) && HAP_SITE_BRIDGE_UPDATE_JSON ) {
		return (string) HAP_SITE_BRIDGE_UPDATE_JSON;
	}
	/*
	 * Public mirror (jsDelivr ← GitHub bbcapt/hap-site-bridge-updates).
	 * CRM still hosts a copy at /hap-bridge-updates/, but SiteGround Anti-Bot AI
	 * often returns HTTP 202/sgcaptcha to fleet hosts (e.g. one.com → CRM),
	 * which breaks Plugin Update Checker. Override with HAP_SITE_BRIDGE_UPDATE_JSON if needed.
	 */
	return 'https://cdn.jsdelivr.net/gh/bbcapt/hap-site-bridge-updates@main/update.json';
}

/**
 * Bootstrap YahnisElsts Plugin Update Checker against Hap private JSON.
 */
function hap_site_bridge_init_updater() {
	$puc = HAP_SITE_BRIDGE_DIR . 'lib/plugin-update-checker/plugin-update-checker.php';
	if ( ! is_readable( $puc ) ) {
		return;
	}

	require_once $puc;

	if ( ! class_exists( '\YahnisElsts\PluginUpdateChecker\v5\PucFactory' ) ) {
		return;
	}

	$checker = \YahnisElsts\PluginUpdateChecker\v5\PucFactory::buildUpdateChecker(
		hap_site_bridge_update_json_url(),
		HAP_SITE_BRIDGE_FILE,
		'hap-site-bridge'
	);

	/**
	 * Optional: filter allows forcing a check after deploy.
	 *
	 * @param object $checker Update checker instance.
	 */
	do_action( 'hap_site_bridge_update_checker', $checker );
}
add_action( 'plugins_loaded', 'hap_site_bridge_init_updater', 5 );

/**
 * Enable WordPress auto-updates for this plugin by default.
 * Disable with: define( 'HAP_SITE_BRIDGE_AUTO_UPDATE', false );
 *
 * @param bool|null $update Whether to update.
 * @param object    $item   Plugin update offer.
 * @return bool|null
 */
function hap_site_bridge_auto_update( $update, $item ) {
	if ( defined( 'HAP_SITE_BRIDGE_AUTO_UPDATE' ) && ! HAP_SITE_BRIDGE_AUTO_UPDATE ) {
		return $update;
	}

	$slug = '';
	if ( is_object( $item ) && ! empty( $item->slug ) ) {
		$slug = (string) $item->slug;
	} elseif ( is_object( $item ) && ! empty( $item->plugin ) ) {
		$slug = dirname( (string) $item->plugin );
	}

	if ( 'hap-site-bridge' === $slug ) {
		return true;
	}

	return $update;
}
add_filter( 'auto_update_plugin', 'hap_site_bridge_auto_update', 10, 2 );
