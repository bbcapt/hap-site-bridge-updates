<?php
/**
 * REST API v2 — signed sessions + editorial deploy.
 *
 * @package HapSiteBridge
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Register hap-bridge/v1 routes (v2 protocol).
 */
class Hap_Bridge_Rest_V2 {

	/**
	 * Bootstrap routes.
	 */
	public function register() {
		register_rest_route(
			'hap-bridge/v1',
			'/connection/status',
			array(
				'methods'             => 'GET',
				'callback'            => array( $this, 'connection_status' ),
				'permission_callback' => '__return_true',
			)
		);

		register_rest_route(
			'hap-bridge/v1',
			'/session/open',
			array(
				'methods'             => 'POST',
				'callback'            => array( $this, 'session_open' ),
				'permission_callback' => '__return_true',
			)
		);

		register_rest_route(
			'hap-bridge/v1',
			'/session/close',
			array(
				'methods'             => 'POST',
				'callback'            => array( $this, 'session_close' ),
				'permission_callback' => '__return_true',
			)
		);

		register_rest_route(
			'hap-bridge/v1',
			'/deploy/article',
			array(
				'methods'             => 'POST',
				'callback'            => array( $this, 'deploy_article' ),
				'permission_callback' => '__return_true',
			)
		);

		register_rest_route(
			'hap-bridge/v1',
			'/content/sitemap',
			array(
				'methods'             => 'GET',
				'callback'            => array( $this, 'content_sitemap' ),
				'permission_callback' => '__return_true',
			)
		);

		register_rest_route(
			'hap-bridge/v1',
			'/media/upload',
			array(
				'methods'             => 'POST',
				'callback'            => array( $this, 'media_upload' ),
				'permission_callback' => '__return_true',
			)
		);

		register_rest_route(
			'hap-bridge/v1',
			'/editorial/capabilities',
			array(
				'methods'             => 'GET',
				'callback'            => array( $this, 'editorial_capabilities' ),
				'permission_callback' => '__return_true',
			)
		);

		register_rest_route(
			'hap-bridge/v1',
			'/editorial/examples',
			array(
				'methods'             => 'GET',
				'callback'            => array( $this, 'editorial_examples' ),
				'permission_callback' => '__return_true',
			)
		);

		register_rest_route(
			'hap-bridge/v1',
			'/editorial/contract',
			array(
				'methods'             => 'GET',
				'callback'            => array( $this, 'editorial_contract' ),
				'permission_callback' => '__return_true',
			)
		);

		register_rest_route(
			'hap-bridge/v1',
			'/editorial/validate',
			array(
				'methods'             => 'POST',
				'callback'            => array( $this, 'editorial_validate' ),
				'permission_callback' => '__return_true',
			)
		);

		register_rest_route(
			'hap-bridge/v1',
			'/editorial/deploy',
			array(
				'methods'             => 'POST',
				'callback'            => array( $this, 'deploy_article' ),
				'permission_callback' => '__return_true',
			)
		);
	}

	/**
	 * @return WP_REST_Response
	 */
	public function connection_status() {
		$https = Hap_Bridge_Auth::require_https();
		if ( is_wp_error( $https ) ) {
			return new WP_REST_Response( array( 'ok' => false, 'error' => $https->get_error_code() ), 403 );
		}
		$c = Hap_Bridge_Connection::get();
		$caps = $this->build_capabilities();
		return new WP_REST_Response(
			array_merge(
				array(
					'ok'             => Hap_Bridge_Connection::is_paired(),
					'bridge_version' => defined( 'HAP_SITE_BRIDGE_VERSION' ) ? HAP_SITE_BRIDGE_VERSION : '',
					'protocol'       => Hap_Bridge_Auth::PROTOCOL,
					'connection_id'  => $c['connection_id'] ? substr( $c['connection_id'], 0, 8 ) . '…' : '',
					'site_id'        => $c['site_id'] ? substr( $c['site_id'], 0, 8 ) . '…' : '',
					'revoked'        => (bool) $c['revoked'],
					'esm_active'     => ! empty( $caps['esm_validate'] ),
				),
				array( 'editorial' => $caps )
			),
			200
		);
	}

	/**
	 * @param WP_REST_Request $request Request.
	 * @return WP_REST_Response|WP_Error
	 */
	public function editorial_capabilities( WP_REST_Request $request ) {
		$auth = Hap_Bridge_Auth::verify_signed_request( $request, 'editorial.read_checks' );
		if ( is_wp_error( $auth ) ) {
			// Allow paired public read of capabilities when signed status works similarly to sitemap.
			$https = Hap_Bridge_Auth::require_https();
			if ( is_wp_error( $https ) ) {
				return $https;
			}
			if ( ! Hap_Bridge_Connection::is_paired() ) {
				return $auth;
			}
		}
		return new WP_REST_Response(
			array(
				'ok'   => true,
				'data' => $this->build_capabilities(),
			),
			200
		);
	}

	/**
	 * @param WP_REST_Request $request Request.
	 * @return WP_REST_Response|WP_Error
	 */
	public function editorial_examples( WP_REST_Request $request ) {
		$auth = Hap_Bridge_Auth::verify_signed_request( $request, 'editorial.read_checks' );
		if ( is_wp_error( $auth ) ) {
			return $auth;
		}
		$post_type = sanitize_key( (string) $request->get_param( 'post_type' ) ?: 'post' );
		$limit     = (int) ( $request->get_param( 'limit' ) ?: 5 );
		$examples  = Hap_Bridge_Serializer::example_posts( $post_type, $limit );
		return new WP_REST_Response(
			array(
				'ok'                => true,
				'post_type'         => $post_type,
				'serialize_version' => Hap_Bridge_Serializer::VERSION,
				'examples'          => $examples,
				'count'             => count( $examples ),
			),
			200
		);
	}

	/**
	 * @param WP_REST_Request $request Request.
	 * @return WP_REST_Response|WP_Error
	 */
	public function editorial_contract( WP_REST_Request $request ) {
		$auth = Hap_Bridge_Auth::verify_signed_request( $request, 'editorial.read_checks' );
		if ( is_wp_error( $auth ) ) {
			return $auth;
		}
		$declared = Hap_Bridge_Serializer::declared_contract();
		if ( ! $declared ) {
			return new WP_REST_Response(
				array(
					'ok'      => false,
					'message' => 'No declared contract on this site (use discovery from examples).',
					'source'  => 'none',
				),
				200
			);
		}
		return new WP_REST_Response(
			array(
				'ok'       => true,
				'source'   => 'declared',
				'contract' => $declared,
			),
			200
		);
	}

	/**
	 * @param WP_REST_Request $request Request.
	 * @return WP_REST_Response|WP_Error
	 */
	public function editorial_validate( WP_REST_Request $request ) {
		$auth = Hap_Bridge_Auth::authorize( $request, 'editorial.create_draft' );
		if ( is_wp_error( $auth ) ) {
			$auth = Hap_Bridge_Auth::authorize( $request, 'editorial.read_checks' );
		}
		if ( is_wp_error( $auth ) ) {
			return $auth;
		}
		$body = $request->get_json_params();
		$article = is_array( $body['article'] ?? null ) ? $body['article'] : ( is_array( $body ) ? $body : array() );
		$result  = Hap_Bridge_Editorial::validate_article( $article );
		if ( is_wp_error( $result ) ) {
			return $result;
		}
		return new WP_REST_Response( $result, ! empty( $result['ok'] ) ? 200 : 422 );
	}

	/**
	 * @return array<string,mixed>
	 */
	private function build_capabilities() {
		$esm_validate = function_exists( 'hap_esm_studio_validate' );
		$esm_apply    = function_exists( 'hap_esm_adapter_hap_studio_apply' );
		$declared     = Hap_Bridge_Serializer::declared_contract();
		$post_types   = get_post_types( array( 'public' => true ), 'names' );
		$profiles     = array();
		if ( $declared ) {
			$profiles[] = array(
				'post_type'  => 'post',
				'profile'    => 'hap-studio-post-v1',
				'apply_mode' => 'hap_studio',
				'adapter'    => 'hap_esm_adapter_hap_studio_apply',
				'source'     => 'declared',
			);
		} else {
			$profiles[] = array(
				'post_type'  => 'post',
				'profile'    => 'article-standard',
				'apply_mode' => 'html_sections',
				'adapter'    => 'generic_meta_map',
				'source'     => 'discovered',
			);
		}
		return array(
			'post_type'         => 'post',
			'profile'           => $declared ? 'hap-studio-post-v1' : 'article-standard',
			'esm_validate'      => $esm_validate,
			'esm_apply'         => $esm_apply,
			'serialize_version' => Hap_Bridge_Serializer::VERSION,
			'post_types'        => array_values( $post_types ),
			'profiles'          => $profiles,
			'declared_contract' => $declared,
			'apply_modes'       => array( 'hap_studio', 'html_sections', 'meta_map' ),
			'capabilities'      => array(
				'hero'           => $esm_apply,
				'sections_h2_h3' => true,
				'faq'            => $esm_apply,
				'cta_preset'     => $esm_apply,
				'featured_image' => true,
				'seo_meta'       => true,
				'jsonld'         => $esm_validate,
				'internal_links' => true,
				'external_links' => true,
				'toc'            => $esm_apply,
				'lists'          => true,
				'author'         => true,
				'examples'       => true,
				'generic_apply'  => true,
				'block_blueprint'=> false,
			),
		);
	}

	/**
	 * @param WP_REST_Request $request Request.
	 * @return WP_REST_Response|WP_Error
	 */
	public function session_open( WP_REST_Request $request ) {
		if ( ! $this->rate_limit( 'session_open' ) ) {
			return new WP_Error( 'hap_bridge_rate_limit', 'Too many requests.', array( 'status' => 429 ) );
		}

		$scope = 'editorial.session_open';
		$auth  = Hap_Bridge_Auth::verify_signed_request( $request, $scope );
		if ( is_wp_error( $auth ) ) {
			return $auth;
		}

		$body = $request->get_json_params();
		if ( ! is_array( $body ) ) {
			return new WP_Error( 'hap_bridge_invalid_json', 'JSON body required.', array( 'status' => 400 ) );
		}

		$conn = Hap_Bridge_Connection::get();
		$scopes = isset( $body['scopes'] ) && is_array( $body['scopes'] ) ? $body['scopes'] : array();
		$allowed = array(
			'editorial.create_draft',
			'editorial.update_draft',
			'editorial.update_metadata',
			'editorial.read_checks',
		);
		$scopes = array_values( array_intersect( $scopes, $allowed ) );
		if ( empty( $scopes ) ) {
			$scopes = array( 'editorial.create_draft', 'editorial.update_metadata', 'editorial.read_checks' );
		}

		$session = Hap_Bridge_Session::create(
			array(
				'connection_id' => $conn['connection_id'],
				'site_id'       => $conn['site_id'],
				'deployment_id' => isset( $body['deployment_id'] ) ? (string) $body['deployment_id'] : '',
				'scopes'        => $scopes,
				'ttl_seconds'   => isset( $body['ttl_seconds'] ) ? (int) $body['ttl_seconds'] : Hap_Bridge_Auth::SESSION_DEFAULT,
			)
		);

		Hap_Bridge_Audit::log(
			array(
				'operation'     => 'session_open',
				'deployment_id' => isset( $body['deployment_id'] ) ? (string) $body['deployment_id'] : '',
				'result'        => 'ok',
			)
		);

		$response = new WP_REST_Response(
			array(
				'ok'         => true,
				'session_id' => $session['session_id'],
				'expires_at' => gmdate( 'c', $session['expires_at'] ),
				'scopes'     => $scopes,
			),
			201
		);
		$response->header( 'X-Hap-Session-Token', $session['token'] );
		return $response;
	}

	/**
	 * @param WP_REST_Request $request Request.
	 * @return WP_REST_Response|WP_Error
	 */
	public function session_close( WP_REST_Request $request ) {
		$auth = Hap_Bridge_Auth::authorize( $request, 'editorial.create_draft' );
		if ( is_wp_error( $auth ) ) {
			// Allow close with any valid session scope.
			$auth = Hap_Bridge_Auth::authorize( $request, 'editorial.read_checks' );
		}
		if ( is_wp_error( $auth ) ) {
			$auth = Hap_Bridge_Auth::verify_signed_request( $request, 'editorial.session_close' );
		}
		if ( is_wp_error( $auth ) ) {
			return $auth;
		}

		$body = $request->get_json_params();
		$sid  = is_array( $body ) && ! empty( $body['session_id'] ) ? (string) $body['session_id'] : '';
		if ( '' === $sid ) {
			return new WP_Error( 'hap_bridge_invalid', 'session_id required.', array( 'status' => 400 ) );
		}
		Hap_Bridge_Session::close( $sid );
		Hap_Bridge_Audit::log( array( 'operation' => 'session_close', 'result' => 'ok' ) );
		return new WP_REST_Response( array( 'ok' => true ), 200 );
	}

	/**
	 * @param WP_REST_Request $request Request.
	 * @return WP_REST_Response|WP_Error
	 */
	public function deploy_article( WP_REST_Request $request ) {
		if ( ! $this->rate_limit( 'deploy' ) ) {
			return new WP_Error( 'hap_bridge_rate_limit', 'Too many requests.', array( 'status' => 429 ) );
		}

		$auth = Hap_Bridge_Auth::authorize( $request, 'editorial.create_draft' );
		if ( is_wp_error( $auth ) ) {
			return $auth;
		}

		$body = $request->get_json_params();
		if ( ! is_array( $body ) ) {
			return new WP_Error( 'hap_bridge_invalid_json', 'JSON body required.', array( 'status' => 400 ) );
		}

		$deployment_id = isset( $body['deployment_id'] ) ? (string) $body['deployment_id'] : '';
		if ( '' === $deployment_id ) {
			return new WP_Error( 'hap_bridge_invalid', 'deployment_id required.', array( 'status' => 400 ) );
		}

		$conn = Hap_Bridge_Connection::get();
		$prev = Hap_Bridge_Idempotency::get( $conn['connection_id'], $deployment_id );
		if ( $prev ) {
			return new WP_REST_Response(
				array(
					'ok'        => true,
					'idempotent'=> true,
					'ack'       => $prev,
				),
				200
			);
		}

		$raw = strlen( (string) $request->get_body() );
		if ( $raw > 2 * 1024 * 1024 ) {
			return new WP_Error( 'hap_bridge_payload_too_large', 'Payload too large.', array( 'status' => 413 ) );
		}

		$result = Hap_Bridge_Editorial::deploy_article( $body );
		if ( is_wp_error( $result ) ) {
			Hap_Bridge_Audit::log(
				array(
					'operation'     => 'deploy_article',
					'deployment_id' => $deployment_id,
					'result'        => 'error',
					'error'         => $result->get_error_code(),
				)
			);
			return $result;
		}

		Hap_Bridge_Idempotency::put( $conn['connection_id'], $deployment_id, $result );

		Hap_Bridge_Audit::log(
			array(
				'operation'     => 'deploy_article',
				'deployment_id' => $deployment_id,
				'post_id'       => $result['post_id'] ?? 0,
				'result'        => 'ok',
			)
		);

		return new WP_REST_Response(
			array(
				'ok'  => true,
				'ack' => $result,
			),
			201
		);
	}

	/**
	 * Inventory of published posts/pages for internal linking.
	 *
	 * @param WP_REST_Request $request Request.
	 * @return WP_REST_Response|WP_Error
	 */
	public function content_sitemap( WP_REST_Request $request ) {
		if ( ! $this->rate_limit( 'sitemap' ) ) {
			return new WP_Error( 'hap_bridge_rate_limit', 'Too many requests.', array( 'status' => 429 ) );
		}
		$auth = Hap_Bridge_Auth::verify_signed_request( $request, 'editorial.read_sitemap' );
		if ( is_wp_error( $auth ) ) {
			return $auth;
		}

		$posts = get_posts(
			array(
				'post_type'      => array( 'post', 'page' ),
				'post_status'    => 'publish',
				'posts_per_page' => 200,
				'orderby'        => 'modified',
				'order'          => 'DESC',
			)
		);
		$pages = array();
		foreach ( $posts as $p ) {
			$pages[] = array(
				'title' => get_the_title( $p ),
				'url'   => get_permalink( $p ),
				'slug'  => $p->post_name,
				'type'  => $p->post_type,
			);
		}

		return new WP_REST_Response(
			array(
				'ok'    => true,
				'pages' => $pages,
				'count' => count( $pages ),
			),
			200
		);
	}

	/**
	 * Upload media (base64) during editorial session.
	 *
	 * @param WP_REST_Request $request Request.
	 * @return WP_REST_Response|WP_Error
	 */
	public function media_upload( WP_REST_Request $request ) {
		if ( ! $this->rate_limit( 'media' ) ) {
			return new WP_Error( 'hap_bridge_rate_limit', 'Too many requests.', array( 'status' => 429 ) );
		}
		$auth = Hap_Bridge_Auth::authorize( $request, 'editorial.create_draft' );
		if ( is_wp_error( $auth ) ) {
			return $auth;
		}

		$body = $request->get_json_params();
		if ( ! is_array( $body ) || empty( $body['data'] ) || empty( $body['filename'] ) ) {
			return new WP_Error( 'hap_bridge_invalid', 'filename and data required.', array( 'status' => 400 ) );
		}

		$filename = sanitize_file_name( (string) $body['filename'] );
		$bin      = base64_decode( (string) $body['data'], true );
		if ( false === $bin || '' === $bin ) {
			return new WP_Error( 'hap_bridge_invalid', 'Invalid base64 data.', array( 'status' => 400 ) );
		}
		if ( strlen( $bin ) > 8 * 1024 * 1024 ) {
			return new WP_Error( 'hap_bridge_payload_too_large', 'Media too large (max 8MB).', array( 'status' => 413 ) );
		}

		require_once ABSPATH . 'wp-admin/includes/file.php';
		require_once ABSPATH . 'wp-admin/includes/media.php';
		require_once ABSPATH . 'wp-admin/includes/image.php';

		$tmp = wp_tempnam( $filename );
		// phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_file_put_contents
		file_put_contents( $tmp, $bin );
		$file_array = array(
			'name'     => $filename,
			'tmp_name' => $tmp,
		);
		$id = media_handle_sideload( $file_array, 0 );
		if ( is_wp_error( $id ) ) {
			@unlink( $tmp ); // phpcs:ignore WordPress.PHP.NoSilencedErrors.Discouraged
			return $id;
		}

		return new WP_REST_Response(
			array(
				'ok'       => true,
				'media_id' => (int) $id,
				'url'      => wp_get_attachment_url( (int) $id ),
			),
			201
		);
	}

	/**
	 * @param string $bucket Bucket name.
	 * @return bool
	 */
	private function rate_limit( $bucket ) {
		$conn = Hap_Bridge_Connection::get();
		$id   = $conn['connection_id'] ? $conn['connection_id'] : 'anon';
		$key  = 'hap_rl_' . $bucket . '_' . hash( 'sha256', $id );
		$n    = (int) get_transient( $key );
		if ( $n > 30 ) {
			return false;
		}
		set_transient( $key, $n + 1, 60 );
		return true;
	}
}
