<?php
/**
 * Per-site HAP connection (pairing) configuration.
 *
 * @package HapSiteBridge
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Connection identity and CRM public keys.
 */
class Hap_Bridge_Connection {

	/**
	 * @return array{connection_id:string,site_id:string,revoked:bool,public_keys:array<string,string>}
	 */
	public static function get() {
		$connection_id = '';
		$site_id       = '';
		$revoked       = false;
		$public_keys   = array();

		if ( defined( 'HAP_BRIDGE_CONNECTION_ID' ) && HAP_BRIDGE_CONNECTION_ID ) {
			$connection_id = (string) HAP_BRIDGE_CONNECTION_ID;
		}
		if ( defined( 'HAP_BRIDGE_SITE_ID' ) && HAP_BRIDGE_SITE_ID ) {
			$site_id = (string) HAP_BRIDGE_SITE_ID;
		}
		if ( defined( 'HAP_BRIDGE_REVOKED' ) && HAP_BRIDGE_REVOKED ) {
			$revoked = true;
		}

		$key_id = defined( 'HAP_BRIDGE_KEY_ID' ) ? (string) HAP_BRIDGE_KEY_ID : 'k1';
		$pub    = '';
		if ( defined( 'HAP_BRIDGE_CRM_PUBLIC_KEY' ) && HAP_BRIDGE_CRM_PUBLIC_KEY ) {
			$pub = (string) HAP_BRIDGE_CRM_PUBLIC_KEY;
		}
		if ( '' !== $pub ) {
			$public_keys[ $key_id ] = $pub;
		}

		$stored = get_option( 'hap_bridge_connection', array() );
		if ( is_array( $stored ) ) {
			if ( '' === $connection_id && ! empty( $stored['connection_id'] ) ) {
				$connection_id = (string) $stored['connection_id'];
			}
			if ( '' === $site_id && ! empty( $stored['site_id'] ) ) {
				$site_id = (string) $stored['site_id'];
			}
			if ( ! empty( $stored['revoked'] ) ) {
				$revoked = true;
			}
			if ( ! empty( $stored['public_keys'] ) && is_array( $stored['public_keys'] ) ) {
				$public_keys = array_merge( $public_keys, $stored['public_keys'] );
			}
		}

		return array(
			'connection_id' => $connection_id,
			'site_id'       => $site_id,
			'revoked'       => $revoked,
			'public_keys'   => $public_keys,
		);
	}

	/**
	 * @return bool
	 */
	public static function is_paired() {
		$c = self::get();
		return '' !== $c['connection_id'] && '' !== $c['site_id'] && ! empty( $c['public_keys'] ) && ! $c['revoked'];
	}

	/**
	 * @param string $key_id Key id header.
	 * @return string Binary public key or empty.
	 */
	public static function public_key_for( $key_id ) {
		$c   = self::get();
		$kid = '' !== $key_id ? $key_id : 'k1';
		if ( empty( $c['public_keys'][ $kid ] ) ) {
			return '';
		}
		$decoded = base64_decode( (string) $c['public_keys'][ $kid ], true );
		return ( false === $decoded ) ? '' : $decoded;
	}
}
