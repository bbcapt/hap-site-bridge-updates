<?php
/**
 * Admin settings UI — save API key without editing wp-config.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Hap_Bridge_Admin {

	const OPTION_API_KEY   = 'hap_site_bridge_api_key';
	const OPTION_WRITE_KEY = 'hap_site_bridge_write_key';
	const PAGE_SLUG        = 'hap-site-bridge';

	public static function init() {
		add_action( 'admin_menu', array( __CLASS__, 'register_menu' ) );
		add_filter( 'plugin_action_links_' . plugin_basename( HAP_SITE_BRIDGE_FILE ), array( __CLASS__, 'action_links' ) );
	}

	/**
	 * @param array<int,string> $links Links.
	 * @return array<int,string>
	 */
	public static function action_links( $links ) {
		$url = admin_url( 'options-general.php?page=' . self::PAGE_SLUG );
		array_unshift(
			$links,
			'<a href="' . esc_url( $url ) . '">' . esc_html__( 'Settings', 'hap-site-bridge' ) . '</a>'
		);
		return $links;
	}

	public static function register_menu() {
		add_options_page(
			__( 'Hap Site Bridge', 'hap-site-bridge' ),
			__( 'Hap Bridge', 'hap-site-bridge' ),
			'manage_options',
			self::PAGE_SLUG,
			array( __CLASS__, 'render_page' )
		);
	}

	public static function render_page() {
		if ( ! current_user_can( 'manage_options' ) ) {
			return;
		}

		if (
			isset( $_POST['hap_bridge_settings_nonce'] )
			&& wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['hap_bridge_settings_nonce'] ) ), 'hap_bridge_save_settings' )
		) {
			self::save_posted();
			echo '<div class="notice notice-success is-dismissible"><p>' . esc_html__( 'Settings saved.', 'hap-site-bridge' ) . '</p></div>';
		}

		$api_locked   = defined( 'HAP_SITE_BRIDGE_API_KEY' ) && HAP_SITE_BRIDGE_API_KEY;
		$write_locked = defined( 'HAP_SITE_BRIDGE_WRITE_KEY' ) && HAP_SITE_BRIDGE_WRITE_KEY;
		$api_set      = hap_site_bridge_api_key() !== '';
		$write_set    = hap_site_bridge_write_key() !== '';
		?>
		<div class="wrap">
			<h1><?php esc_html_e( 'Hap Site Bridge', 'hap-site-bridge' ); ?></h1>
			<p><?php esc_html_e( 'Paste the same read API key stored in HAP OS (Sites → Hap Bridge → Credentials). No wp-config edit required.', 'hap-site-bridge' ); ?></p>

			<form method="post">
				<?php wp_nonce_field( 'hap_bridge_save_settings', 'hap_bridge_settings_nonce' ); ?>
				<table class="form-table" role="presentation">
					<tr>
						<th scope="row">
							<label for="hap_site_bridge_api_key"><?php esc_html_e( 'Read API key', 'hap-site-bridge' ); ?></label>
						</th>
						<td>
							<?php if ( $api_locked ) : ?>
								<input type="text" class="regular-text" value="<?php esc_attr_e( 'Set in wp-config (HAP_SITE_BRIDGE_API_KEY)', 'hap-site-bridge' ); ?>" disabled />
								<p class="description"><?php esc_html_e( 'Constant overrides the field below.', 'hap-site-bridge' ); ?></p>
							<?php else : ?>
								<input
									type="password"
									class="regular-text"
									id="hap_site_bridge_api_key"
									name="hap_site_bridge_api_key"
									value=""
									autocomplete="new-password"
									placeholder="<?php echo $api_set ? esc_attr__( '•••• saved — paste to replace', 'hap-site-bridge' ) : esc_attr__( 'Paste API key from HAP OS', 'hap-site-bridge' ); ?>"
								/>
								<p class="description">
									<?php
									echo $api_set
										? esc_html__( 'A key is already saved. Leave blank to keep it, or paste a new one to replace.', 'hap-site-bridge' )
										: esc_html__( 'Required for HAP OS site analysis (GET hap/v1/data).', 'hap-site-bridge' );
									?>
								</p>
							<?php endif; ?>
						</td>
					</tr>
					<tr>
						<th scope="row">
							<label for="hap_site_bridge_write_key"><?php esc_html_e( 'Write key (optional)', 'hap-site-bridge' ); ?></label>
						</th>
						<td>
							<?php if ( $write_locked ) : ?>
								<input type="text" class="regular-text" value="<?php esc_attr_e( 'Set in wp-config (HAP_SITE_BRIDGE_WRITE_KEY)', 'hap-site-bridge' ); ?>" disabled />
							<?php else : ?>
								<input
									type="password"
									class="regular-text"
									id="hap_site_bridge_write_key"
									name="hap_site_bridge_write_key"
									value=""
									autocomplete="new-password"
									placeholder="<?php echo $write_set ? esc_attr__( '•••• saved — paste to replace', 'hap-site-bridge' ) : esc_attr__( 'Optional', 'hap-site-bridge' ); ?>"
								/>
								<p class="description"><?php esc_html_e( 'Only for legacy draft write. Leave empty if unused.', 'hap-site-bridge' ); ?></p>
							<?php endif; ?>
						</td>
					</tr>
					<tr>
						<th scope="row"><?php esc_html_e( 'Status', 'hap-site-bridge' ); ?></th>
						<td>
							<p>
								<strong><?php esc_html_e( 'Version', 'hap-site-bridge' ); ?>:</strong>
								<?php echo esc_html( HAP_SITE_BRIDGE_VERSION ); ?>
							</p>
							<p>
								<strong><?php esc_html_e( 'Read API key', 'hap-site-bridge' ); ?>:</strong>
								<?php echo $api_set ? esc_html__( 'configured', 'hap-site-bridge' ) : esc_html__( 'missing', 'hap-site-bridge' ); ?>
							</p>
						</td>
					</tr>
				</table>
				<?php submit_button( __( 'Save settings', 'hap-site-bridge' ) ); ?>
			</form>
		</div>
		<?php
	}

	private static function save_posted() {
		if ( ! current_user_can( 'manage_options' ) ) {
			return;
		}

		if ( ! ( defined( 'HAP_SITE_BRIDGE_API_KEY' ) && HAP_SITE_BRIDGE_API_KEY ) ) {
			$api = isset( $_POST['hap_site_bridge_api_key'] ) ? trim( (string) wp_unslash( $_POST['hap_site_bridge_api_key'] ) ) : '';
			if ( $api !== '' ) {
				update_option( self::OPTION_API_KEY, $api, false );
			}
		}

		if ( ! ( defined( 'HAP_SITE_BRIDGE_WRITE_KEY' ) && HAP_SITE_BRIDGE_WRITE_KEY ) ) {
			$write = isset( $_POST['hap_site_bridge_write_key'] ) ? trim( (string) wp_unslash( $_POST['hap_site_bridge_write_key'] ) ) : '';
			if ( $write !== '' ) {
				update_option( self::OPTION_WRITE_KEY, $write, false );
			}
		}
	}
}
