<?php
/**
 * Cleanup on plugin delete — options only (wp-config is never auto-edited).
 */

if ( ! defined( 'WP_UNINSTALL_PLUGIN' ) ) {
	exit;
}

$options = array(
	'hap_site_bridge_api_key',
	'hap_site_bridge_write_key',
	'hap_site_bridge_analysis_disabled',
	'hap_bridge_connection',
	'hap_bridge_audit_log',
);

foreach ( $options as $option ) {
	delete_option( $option );
}

// Idempotency leftovers (hap_bridge_idem_*).
global $wpdb;
if ( isset( $wpdb ) ) {
	// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
	$wpdb->query( "DELETE FROM {$wpdb->options} WHERE option_name LIKE 'hap_bridge_idem_%'" );
}
