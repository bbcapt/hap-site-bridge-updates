# Hap Site Bridge

Thin WordPress plugin for **Hap-managed** sites only.

## What it does

| Endpoint | Auth | Purpose |
|----------|------|---------|
| `GET /wp-json/hap/v1/data/?api-key=…` | Read API key | Site health for CRM (encrypted slots) |
| `POST /wp-json/hap/v1/content/draft` | Application Password **or** write key header | Legacy draft JSON |
| `POST /wp-json/hap-bridge/v1/session/open` | Ed25519 signed (CRM) | Short-lived write session |
| `POST /wp-json/hap-bridge/v1/deploy/article` | Session token | Editorial deploy via HAP ESM |

Never auto-publishes. See `docs/hap-bridge-auth-v1.md` in CRM repo for pairing (v1.2.0+).

## Install

1. Copy `hap-site-bridge/` into `wp-content/plugins/` (or install from private update zip) and activate.
2. **Settings → Hap Bridge** — paste the same read API key stored in HAP OS / CRM (`website_api_key`).  
   No `wp-config` edit required for the API key (v1.4.1+).
3. Optional overrides in `wp-config.php` (constants win over the settings UI):

```php
define('HAP_SITE_BRIDGE_API_KEY', '…same as CRM website_api_key…');
define('HAP_CRM_ENCRYPT_IV', '7846290857246738'); // same as CRM (defaults baked in)
define('HAP_CRM_ENCRYPT_KEY', '…same as CRM…');     // defaults baked in
// Optional write key for content hub:
// define('HAP_SITE_BRIDGE_WRITE_KEY', '…long random…');
// Optional: disable auto-updates
// define('HAP_SITE_BRIDGE_AUTO_UPDATE', false);
```

4. On HAP OS / CRM: store the same read key; site `crm_url` must end with `/`.

## Auto-updates (Hap fleet)

From **1.4.2**, sites check the **public** channel (avoids SiteGround Captcha on CRM):

`https://crm.hap-studio.it/hap-bridge-updates/update.json`
(Plugin ≥1.4.6 also probes GitHub raw + jsDelivr and picks the newest version.)

Source repo: [bbcapt/hap-site-bridge-updates](https://github.com/bbcapt/hap-site-bridge-updates).  
CRM keeps **two** mirrors (both must be updated on every release):
- `https://crm.hap-studio.it/hap-bridge-updates/`
- `https://crm.hap-studio.it/wp-content/uploads/hap-bridge-updates/`

- In **Plugin** list they see when a newer version is available.
- **Auto-update is on by default**. Turn off with `HAP_SITE_BRIDGE_AUTO_UPDATE` false.
- Override URL: `define('HAP_SITE_BRIDGE_UPDATE_JSON', '…');`

### Publish a new release (from this repo)

```bash
cd packages/hap-site-bridge
chmod +x bin/build-release.sh
HAP_BRIDGE_PUBLISH=1 ./bin/build-release.sh 1.4.2
# builds zip + update.json, rsync → CRM, commit/push → hap-site-bridge-updates
```

Sites already on **≥ 1.4.2** pick updates automatically.  
Sites on **≤ 1.4.1** still point at CRM JSON (often blocked) → one manual install of 1.4.2+ required.

## Offboarding (lose client / hand to another agency)

Checklist (do in order):

1. CRM: set website status `closed`, clear `website_api_key` (and any future write-key field).
2. Site: deactivate + delete **Hap Site Bridge** (and any mu-plugin copy).
3. Remove `HAP_SITE_BRIDGE_*` / encrypt constants from `wp-config` if unused.
4. Optional: rotate/invalidate the key on CRM if reused elsewhere.
5. Deliver theme + content **without** this plugin.

Site keeps working; CRM stops receiving data. Do **not** leave this plugin on handoff.

## Write draft example

```bash
curl -X POST 'https://example.com/wp-json/hap/v1/content/draft' \
  -H 'Content-Type: application/json' \
  -H 'X-Hap-Bridge-Write-Key: YOUR_WRITE_KEY' \
  -d '{"slug":"test-article","title":"Test","status":"draft","content_html":"<p>Hi</p>","profile":"hap-studio"}'
```

Or Basic auth with a WP Application Password for a user who can `edit_posts`.

## Security notes

- Do not commit API keys into client theme repos.
- Read key ≠ write key.
- Remove plugin before handing the site to another developer.
- Update zip URL is intentionally public-read (plugin code is not secret); protect CRM access separately.
