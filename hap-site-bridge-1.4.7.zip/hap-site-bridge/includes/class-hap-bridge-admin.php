<?php
/**
 * Admin settings — UI italiana, un solo campo chiave in evidenza.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Hap_Bridge_Admin {

	const OPTION_API_KEY           = 'hap_site_bridge_api_key';
	const OPTION_WRITE_KEY         = 'hap_site_bridge_write_key';
	const OPTION_ANALYSIS_DISABLED = 'hap_site_bridge_analysis_disabled';
	const PAGE_SLUG                = 'hap-site-bridge';

	public static function init() {
		add_action( 'admin_menu', array( __CLASS__, 'register_menu' ) );
		add_filter( 'plugin_action_links_' . plugin_basename( HAP_SITE_BRIDGE_FILE ), array( __CLASS__, 'action_links' ) );
	}

	/**
	 * @param array<int,string> $links Links.
	 * @return array<int,string>
	 */
	public static function action_links( $links ) {
		$url = admin_url( 'options-general.php?page=' . self::PAGE_SLUG );
		array_unshift(
			$links,
			'<a href="' . esc_url( $url ) . '">Impostazioni</a>'
		);
		return $links;
	}

	public static function register_menu() {
		add_options_page(
			'Hap Bridge',
			'Hap Bridge',
			'manage_options',
			self::PAGE_SLUG,
			array( __CLASS__, 'render_page' )
		);
	}

	public static function render_page() {
		if ( ! current_user_can( 'manage_options' ) ) {
			return;
		}

		$notice = '';
		$notice_type = 'success';
		if (
			isset( $_POST['hap_bridge_settings_nonce'] )
			&& wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['hap_bridge_settings_nonce'] ) ), 'hap_bridge_save_settings' )
		) {
			$result = self::save_posted();
			$notice = $result['message'];
			$notice_type = $result['type'];
		}

		$api_locked  = defined( 'HAP_SITE_BRIDGE_API_KEY' ) && HAP_SITE_BRIDGE_API_KEY && ! hap_site_bridge_analysis_disabled();
		$api_set     = hap_site_bridge_api_key() !== '';
		$write_set   = hap_site_bridge_write_key() !== '';
		$v2_paired   = Hap_Bridge_Connection::is_paired();
		$connected   = $api_set;
		$can_unpair  = $api_set || $write_set || $v2_paired || hap_site_bridge_analysis_disabled()
			|| ( defined( 'HAP_SITE_BRIDGE_API_KEY' ) && HAP_SITE_BRIDGE_API_KEY )
			|| Hap_Bridge_Connection::is_locked_by_constants();
		?>
		<div class="wrap">
			<h1>Hap Bridge</h1>
			<p style="max-width: 40rem; font-size: 14px; line-height: 1.5;">
				Collega questo sito a <strong>HAP OS</strong> così possiamo leggere salute, versioni e segnali del sito.
				Serve <strong>una sola chiave</strong>: la copi da HAP OS → Siti → Connector → «Copia per il plugin».
			</p>

			<?php if ( $notice ) : ?>
				<div class="notice notice-<?php echo esc_attr( $notice_type ); ?> is-dismissible"><p><?php echo esc_html( $notice ); ?></p></div>
			<?php endif; ?>

			<?php if ( defined( 'HAP_SITE_BRIDGE_API_KEY' ) && HAP_SITE_BRIDGE_API_KEY ) : ?>
				<div class="notice notice-warning">
					<p>
						In <code>wp-config.php</code> c’è ancora una chiave vecchia
						(<code>HAP_SITE_BRIDGE_API_KEY</code>). Meglio toglierla e usare solo il campo qui sotto.
						Finché resta lì, ha priorità sul campo.
					</p>
				</div>
			<?php endif; ?>

			<div class="card" style="max-width: 40rem; padding: 1rem 1.25rem; margin: 1rem 0;">
				<h2 style="margin-top: 0;">Stato</h2>
				<p style="font-size: 16px; margin: 0.25rem 0 0.75rem;">
					<?php if ( $connected ) : ?>
						<strong style="color: #1d6f42;">Collegato</strong>
						— HAP OS può leggere i dati di questo sito.
					<?php else : ?>
						<strong style="color: #8a2424;">Non collegato</strong>
						— incolla la chiave qui sotto e salva.
					<?php endif; ?>
				</p>
				<p style="margin: 0; color: #646970; font-size: 13px;">
					Versione plugin: <strong><?php echo esc_html( HAP_SITE_BRIDGE_VERSION ); ?></strong>
					<?php if ( $v2_paired ) : ?>
						· Collegamento editoriale (v2): attivo
					<?php endif; ?>
				</p>
			</div>

			<form method="post" style="max-width: 40rem;">
				<?php wp_nonce_field( 'hap_bridge_save_settings', 'hap_bridge_settings_nonce' ); ?>

				<h2>1. Chiave di collegamento</h2>
				<p style="color: #646970; max-width: 36rem;">
					È l’unica chiave che serve per il lavoro normale (analisi sito da HAP OS).
					Non serve modificare <code>wp-config</code>.
				</p>

				<table class="form-table" role="presentation">
					<tr>
						<th scope="row">
							<label for="hap_site_bridge_api_key">Chiave</label>
						</th>
						<td>
							<?php if ( $api_locked ) : ?>
								<input type="text" class="regular-text" value="Bloccata da wp-config" disabled />
								<p class="description">
									Rimuovi <code>HAP_SITE_BRIDGE_API_KEY</code> da wp-config, oppure usa «Scollega» qui sotto.
								</p>
							<?php else : ?>
								<input
									type="password"
									class="regular-text"
									id="hap_site_bridge_api_key"
									name="hap_site_bridge_api_key"
									value=""
									autocomplete="new-password"
									placeholder="<?php echo $api_set ? '•••• già salvata — incolla per sostituire' : 'Incolla la chiave da HAP OS'; ?>"
								/>
								<p class="description">
									<?php if ( $api_set ) : ?>
										Chiave già presente. Lascia vuoto per tenerla, oppure incollane una nuova e salva.
									<?php else : ?>
										HAP OS → Siti → apri il sito → Connector → «Mostra / Copia key».
									<?php endif; ?>
								</p>
							<?php endif; ?>
						</td>
					</tr>
				</table>

				<?php submit_button( 'Salva chiave', 'primary', 'submit', false ); ?>
			</form>

			<?php if ( $can_unpair ) : ?>
				<hr style="margin: 2rem 0 1rem; max-width: 40rem;" />
				<h2>2. Scollega</h2>
				<p style="color: #646970; max-width: 36rem;">
					Toglie la chiave da questo sito. Dopo, in HAP OS il sito risulta «Non collegato»
					(alla prossima verifica Bridge). Usa questo per test o per handoff al cliente.
				</p>
				<form
					method="post"
					style="margin: 0.75rem 0;"
					onsubmit="return confirm('Scollegare questo sito da HAP OS? La chiave verrà cancellata qui.');"
				>
					<?php wp_nonce_field( 'hap_bridge_save_settings', 'hap_bridge_settings_nonce' ); ?>
					<input type="hidden" name="hap_bridge_action" value="unpair_all" />
					<?php submit_button( 'Scollega da HAP OS', 'delete', 'submit', false ); ?>
				</form>
			<?php endif; ?>

			<hr style="margin: 2rem 0 1rem; max-width: 40rem;" />
			<h2>3. Aggiornamenti plugin</h2>
			<p style="color: #646970; max-width: 36rem;">
				Controlla se esiste una versione più nuova del Bridge (canale Hap).
			</p>
			<form method="post" style="margin: 0.75rem 0;">
				<?php wp_nonce_field( 'hap_bridge_save_settings', 'hap_bridge_settings_nonce' ); ?>
				<input type="hidden" name="hap_bridge_action" value="force_update_check" />
				<?php submit_button( 'Controlla aggiornamenti', 'secondary', 'submit', false ); ?>
			</form>

			<?php if ( $write_set || ( defined( 'HAP_SITE_BRIDGE_WRITE_KEY' ) && HAP_SITE_BRIDGE_WRITE_KEY ) ) : ?>
				<details style="margin-top: 2rem; max-width: 40rem;">
					<summary style="cursor: pointer; font-weight: 600;">Opzioni avanzate (di solito non servono)</summary>
					<p style="color: #646970;">
						La «write key» serve solo a funzioni editoriali vecchie. Per l’analisi siti
						<strong>non serve</strong> — basta la chiave di collegamento sopra.
					</p>
					<form method="post">
						<?php wp_nonce_field( 'hap_bridge_save_settings', 'hap_bridge_settings_nonce' ); ?>
						<p>
							<label>
								<input type="checkbox" name="hap_bridge_clear_write_key" value="1" />
								Rimuovi write key
							</label>
						</p>
						<?php submit_button( 'Salva opzioni avanzate', 'secondary', 'submit', false ); ?>
					</form>
				</details>
			<?php endif; ?>
		</div>
		<?php
	}

	/**
	 * @return array{message:string,type:string}
	 */
	private static function save_posted() {
		if ( ! current_user_can( 'manage_options' ) ) {
			return array( 'message' => '', 'type' => 'success' );
		}

		$action = isset( $_POST['hap_bridge_action'] ) ? sanitize_text_field( wp_unslash( $_POST['hap_bridge_action'] ) ) : '';

		if ( 'force_update_check' === $action ) {
			$remote = hap_site_bridge_force_update_check();
			if ( $remote && version_compare( $remote, HAP_SITE_BRIDGE_VERSION, '>' ) ) {
				return array(
					'message' => 'È disponibile la versione ' . $remote . '. Vai su Dashboard → Aggiornamenti (o Plugin) e aggiorna.',
					'type'    => 'success',
				);
			}
			if ( $remote ) {
				return array(
					'message' => 'Sei già aggiornato (canale: ' . $remote . ').',
					'type'    => 'success',
				);
			}
			return array(
				'message' => 'Controllo fatto: nessuna versione più nuova trovata.',
				'type'    => 'success',
			);
		}

		if ( 'unpair_all' === $action ) {
			delete_option( self::OPTION_API_KEY );
			delete_option( self::OPTION_WRITE_KEY );
			update_option( self::OPTION_ANALYSIS_DISABLED, '1', false );
			Hap_Bridge_Connection::unpair();
			$msg = 'Sito scollegato. HAP OS vedrà «Non collegato» dopo la prossima verifica Bridge.';
			if ( defined( 'HAP_SITE_BRIDGE_API_KEY' ) && HAP_SITE_BRIDGE_API_KEY ) {
				$msg .= ' Attenzione: in wp-config c’è ancora HAP_SITE_BRIDGE_API_KEY — va rimossa a mano per una pulizia completa.';
			}
			if ( Hap_Bridge_Connection::is_locked_by_constants() ) {
				$msg .= ' Restano anche costanti HAP_BRIDGE_* in wp-config.';
			}
			return array( 'message' => $msg, 'type' => 'success' );
		}

		if ( ! empty( $_POST['hap_bridge_clear_write_key'] ) ) {
			delete_option( self::OPTION_WRITE_KEY );
			return array( 'message' => 'Write key rimossa.', 'type' => 'success' );
		}

		if ( ! ( defined( 'HAP_SITE_BRIDGE_API_KEY' ) && HAP_SITE_BRIDGE_API_KEY && ! hap_site_bridge_analysis_disabled() ) ) {
			$api = isset( $_POST['hap_site_bridge_api_key'] ) ? trim( (string) wp_unslash( $_POST['hap_site_bridge_api_key'] ) ) : '';
			if ( $api !== '' ) {
				update_option( self::OPTION_API_KEY, $api, false );
				delete_option( self::OPTION_ANALYSIS_DISABLED );
				return array(
					'message' => 'Chiave salvata. Il sito è collegato — in HAP OS usa «Verifica Bridge».',
					'type'    => 'success',
				);
			}
		}

		return array( 'message' => 'Nessuna modifica.', 'type' => 'info' );
	}
}
