<?php
/**
 * Private update channel + auto-updates for Hap-managed sites.
 *
 * Metadata is resolved from multiple mirrors; the highest version wins.
 * This avoids sticky CDN edges (jsDelivr @main) reporting "up to date".
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Candidate metadata URLs (first reachable with newest version wins).
 *
 * @return array<int,string>
 */
function hap_site_bridge_update_json_candidates() {
	if ( defined( 'HAP_SITE_BRIDGE_UPDATE_JSON' ) && HAP_SITE_BRIDGE_UPDATE_JSON ) {
		return array( (string) HAP_SITE_BRIDGE_UPDATE_JSON );
	}

	return array(
		// CRM — short Cache-Control on update.json; historically the working channel.
		'https://crm.hap-studio.it/hap-bridge-updates/update.json',
		// GitHub raw — source of truth for the public repo.
		'https://raw.githubusercontent.com/bbcapt/hap-site-bridge-updates/main/update.json',
		// jsDelivr — fleet default on 1.4.2–1.4.3; kept as last fallback (can stick).
		'https://cdn.jsdelivr.net/gh/bbcapt/hap-site-bridge-updates@main/update.json',
	);
}

/**
 * Default / last-known-good metadata URL (no network).
 *
 * @return string
 */
function hap_site_bridge_update_json_url() {
	$candidates = hap_site_bridge_update_json_candidates();
	return (string) $candidates[0];
}

/**
 * Probe mirrors and return the URL advertising the newest version.
 *
 * @return string
 */
function hap_site_bridge_resolve_update_json_url() {
	$candidates = hap_site_bridge_update_json_candidates();
	$best_url   = $candidates[0];
	$best_ver   = '0';

	foreach ( $candidates as $url ) {
		$probe = add_query_arg(
			'hap_cb',
			(string) time(),
			$url
		);
		$response = wp_remote_get(
			$probe,
			array(
				'timeout'     => 8,
				'redirection' => 3,
				'headers'     => array(
					'Accept'         => 'application/json',
					'Cache-Control'  => 'no-cache',
					'Pragma'         => 'no-cache',
				),
			)
		);
		if ( is_wp_error( $response ) ) {
			continue;
		}
		$code = (int) wp_remote_retrieve_response_code( $response );
		if ( $code < 200 || $code >= 300 ) {
			continue;
		}
		$body = (string) wp_remote_retrieve_body( $response );
		$data = json_decode( $body, true );
		if ( ! is_array( $data ) || empty( $data['version'] ) ) {
			continue;
		}
		$ver = (string) $data['version'];
		if ( version_compare( $ver, $best_ver, '>' ) ) {
			$best_ver = $ver;
			// Store clean URL (PUC appends its own query args).
			$best_url = $url;
		}
	}

	return $best_url;
}

/**
 * @var object|null
 */
$GLOBALS['hap_site_bridge_update_checker'] = null;

/**
 * Bootstrap YahnisElsts Plugin Update Checker against Hap private JSON.
 */
function hap_site_bridge_init_updater() {
	$puc = HAP_SITE_BRIDGE_DIR . 'lib/plugin-update-checker/plugin-update-checker.php';
	if ( ! is_readable( $puc ) ) {
		return;
	}

	require_once $puc;

	if ( ! class_exists( '\YahnisElsts\PluginUpdateChecker\v5\PucFactory' ) ) {
		return;
	}

	// Check hourly (was 12h) so releases show up the same day.
	$checker = \YahnisElsts\PluginUpdateChecker\v5\PucFactory::buildUpdateChecker(
		hap_site_bridge_update_json_url(),
		HAP_SITE_BRIDGE_FILE,
		'hap-site-bridge',
		1
	);

	$GLOBALS['hap_site_bridge_update_checker'] = $checker;

	if ( method_exists( $checker, 'addHttpRequestArgFilter' ) ) {
		$checker->addHttpRequestArgFilter(
			static function ( $args ) {
				if ( ! is_array( $args ) ) {
					$args = array();
				}
				if ( empty( $args['headers'] ) || ! is_array( $args['headers'] ) ) {
					$args['headers'] = array();
				}
				$args['headers']['Cache-Control'] = 'no-cache';
				$args['headers']['Pragma']        = 'no-cache';
				$args['timeout']                  = 15;
				return $args;
			}
		);
	}

	// Before WP/PUC checks, point at the freshest mirror.
	add_action(
		'admin_init',
		static function () use ( $checker ) {
			if ( ! is_object( $checker ) ) {
				return;
			}
			$checker->metadataUrl = hap_site_bridge_resolve_update_json_url();
		},
		1
	);

	/**
	 * Optional: filter allows forcing a check after deploy.
	 *
	 * @param object $checker Update checker instance.
	 */
	do_action( 'hap_site_bridge_update_checker', $checker );
}
add_action( 'plugins_loaded', 'hap_site_bridge_init_updater', 5 );

/**
 * Enable WordPress auto-updates for this plugin by default.
 * Disable with: define( 'HAP_SITE_BRIDGE_AUTO_UPDATE', false );
 *
 * @param bool|null $update Whether to update.
 * @param object    $item   Plugin update offer.
 * @return bool|null
 */
function hap_site_bridge_auto_update( $update, $item ) {
	if ( defined( 'HAP_SITE_BRIDGE_AUTO_UPDATE' ) && ! HAP_SITE_BRIDGE_AUTO_UPDATE ) {
		return $update;
	}

	$slug = '';
	if ( is_object( $item ) && ! empty( $item->slug ) ) {
		$slug = (string) $item->slug;
	} elseif ( is_object( $item ) && ! empty( $item->plugin ) ) {
		$slug = dirname( (string) $item->plugin );
	}

	if ( 'hap-site-bridge' === $slug ) {
		return true;
	}

	return $update;
}
add_filter( 'auto_update_plugin', 'hap_site_bridge_auto_update', 10, 2 );

/**
 * Clear PUC caches and force a remote check (admin action).
 *
 * @return string|null New remote version or null.
 */
function hap_site_bridge_force_update_check() {
	$checker = isset( $GLOBALS['hap_site_bridge_update_checker'] )
		? $GLOBALS['hap_site_bridge_update_checker']
		: null;
	if ( ! is_object( $checker ) || ! method_exists( $checker, 'checkForUpdates' ) ) {
		return null;
	}

	$checker->metadataUrl = hap_site_bridge_resolve_update_json_url();

	// Drop WP + PUC update caches so the next check hits the network.
	delete_site_transient( 'update_plugins' );
	delete_transient( 'update_plugins' );
	global $wpdb;
	if ( isset( $wpdb ) && is_object( $wpdb ) ) {
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
		$wpdb->query(
			"DELETE FROM {$wpdb->options} WHERE option_name LIKE '\\_site\\_transient\\_puc\\_%' OR option_name LIKE '\\_transient\\_puc\\_%' OR option_name LIKE '\\_site\\_transient\\_timeout\\_puc\\_%' OR option_name LIKE '\\_transient\\_timeout\\_puc\\_%'"
		);
	}

	$update = $checker->checkForUpdates();
	if ( is_object( $update ) && ! empty( $update->version ) ) {
		return (string) $update->version;
	}
	return null;
}
