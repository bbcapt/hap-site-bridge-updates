<?php
/**
 * Plugin Name: Hap Site Bridge
 * Description: Thin CRM bridge for Hap-managed sites. Read health for CRM; write article drafts. Remove on client handoff.
 * Version: 1.4.7
 * Author: Hap Studio
 * Text Domain: hap-site-bridge
 * Update URI: https://crm.hap-studio.it/hap-bridge-updates/update.json
 *
 * Offboarding: deactivate + delete this plugin, clear HAP_SITE_BRIDGE_* from wp-config.
 * Do not ship this plugin with client deliverables.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

define( 'HAP_SITE_BRIDGE_VERSION', '1.4.7' );
define( 'HAP_SITE_BRIDGE_FILE', __FILE__ );
define( 'HAP_SITE_BRIDGE_DIR', plugin_dir_path( __FILE__ ) );

require_once HAP_SITE_BRIDGE_DIR . 'includes/class-hap-bridge-crypto.php';
require_once HAP_SITE_BRIDGE_DIR . 'includes/class-hap-bridge-collector.php';
require_once HAP_SITE_BRIDGE_DIR . 'includes/class-hap-bridge-rest-data.php';
require_once HAP_SITE_BRIDGE_DIR . 'includes/class-hap-bridge-rest-draft.php';
require_once HAP_SITE_BRIDGE_DIR . 'includes/class-hap-bridge-connection.php';
require_once HAP_SITE_BRIDGE_DIR . 'includes/class-hap-bridge-auth.php';
require_once HAP_SITE_BRIDGE_DIR . 'includes/class-hap-bridge-session.php';
require_once HAP_SITE_BRIDGE_DIR . 'includes/class-hap-bridge-idempotency.php';
require_once HAP_SITE_BRIDGE_DIR . 'includes/class-hap-bridge-audit.php';
require_once HAP_SITE_BRIDGE_DIR . 'includes/class-hap-bridge-editorial.php';
require_once HAP_SITE_BRIDGE_DIR . 'includes/class-hap-bridge-serializer.php';
require_once HAP_SITE_BRIDGE_DIR . 'includes/class-hap-bridge-rest-v2.php';
require_once HAP_SITE_BRIDGE_DIR . 'includes/class-hap-bridge-updater.php';
require_once HAP_SITE_BRIDGE_DIR . 'includes/class-hap-bridge-admin.php';

Hap_Bridge_Admin::init();

/**
 * Bootstrap REST routes.
 */
function hap_site_bridge_register_rest() {
	$data = new Hap_Bridge_Rest_Data();
	$data->register();

	$draft = new Hap_Bridge_Rest_Draft();
	$draft->register();

	$v2 = new Hap_Bridge_Rest_V2();
	$v2->register();
}
add_action( 'rest_api_init', 'hap_site_bridge_register_rest' );

/**
 * Gateway auth for other HAP plugins (e.g. Editorial).
 *
 * @param WP_REST_Request $request Request.
 * @param string          $scope Scope.
 * @return true|WP_Error
 */
function hap_bridge_authorize( $request, $scope ) {
	return Hap_Bridge_Auth::authorize( $request, $scope );
}

/**
 * Soft-unpair flag: lets Settings → Unpair disable analysis even when
 * HAP_SITE_BRIDGE_API_KEY is still defined in wp-config (legacy installs).
 *
 * @return bool
 */
function hap_site_bridge_analysis_disabled() {
	return (string) get_option( 'hap_site_bridge_analysis_disabled', '' ) === '1';
}

/**
 * @return string
 */
function hap_site_bridge_api_key() {
	if ( hap_site_bridge_analysis_disabled() ) {
		return '';
	}
	if ( defined( 'HAP_SITE_BRIDGE_API_KEY' ) && HAP_SITE_BRIDGE_API_KEY ) {
		return (string) HAP_SITE_BRIDGE_API_KEY;
	}
	return (string) get_option( 'hap_site_bridge_api_key', '' );
}

/**
 * @return string
 */
function hap_site_bridge_write_key() {
	if ( defined( 'HAP_SITE_BRIDGE_WRITE_KEY' ) && HAP_SITE_BRIDGE_WRITE_KEY ) {
		return (string) HAP_SITE_BRIDGE_WRITE_KEY;
	}
	return (string) get_option( 'hap_site_bridge_write_key', '' );
}
